#pragma once

#include <new>
#include "bridge/OnOff.h"
#include "bridge/LevelControl.h"
#include "bridge/Descriptor.h"
#include "bridge/Switch.h"
#include "bridge/TemperatureMeasurement.h"

namespace clusters {

struct ClusterInfo
{
  chip::ClusterId id;
  const char *name;
  uint16_t size;
  GeneratedCluster* (*ctor)(void*);
} static const kKnownClusters[] = {

  {
    6,
    "OnOff",
    sizeof(OnOffCluster),
    [](void *mem) -> GeneratedCluster* {
      return new(mem) OnOffCluster();
    },
  },
  {
    8,
    "LevelControl",
    sizeof(LevelControlCluster),
    [](void *mem) -> GeneratedCluster* {
      return new(mem) LevelControlCluster();
    },
  },
  {
    29,
    "Descriptor",
    sizeof(DescriptorCluster),
    [](void *mem) -> GeneratedCluster* {
      return new(mem) DescriptorCluster();
    },
  },
  {
    59,
    "Switch",
    sizeof(SwitchCluster),
    [](void *mem) -> GeneratedCluster* {
      return new(mem) SwitchCluster();
    },
  },
  {
    1026,
    "TemperatureMeasurement",
    sizeof(TemperatureMeasurementCluster),
    [](void *mem) -> GeneratedCluster* {
      return new(mem) TemperatureMeasurementCluster();
    },
  },
};

}
