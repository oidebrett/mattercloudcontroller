#pragma once

#include "BridgeGlobalStructs.h"
#include "GeneratedClusters.h"

namespace clusters {
struct SwitchCluster : public GeneratedCluster
{

  SwitchCluster() :
      mNumberOfPositions(chip::CharSpan("numberOfPositions"), 0, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mCurrentPosition(chip::CharSpan("currentPosition"), 1, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mMultiPressMax(chip::CharSpan("multiPressMax"), 2, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mGeneratedCommandList(chip::CharSpan("generatedCommandList"), 65528, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mAcceptedCommandList(chip::CharSpan("acceptedCommandList"), 65529, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mEventList(chip::CharSpan("eventList"), 65530, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mAttributeList(chip::CharSpan("attributeList"), 65531, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mFeatureMap(chip::CharSpan("featureMap"), 65532, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_BITMAP32_ATTRIBUTE_TYPE, 4),
      mClusterRevision(chip::CharSpan("clusterRevision"), 65533, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2, ZCL_SWITCH_CLUSTER_REVISION)
  {
  }

  static constexpr uint32_t kClusterId =59;
  chip::ClusterId GetClusterId() override { return kClusterId; }

  std::vector<AttributeInterface*> GetAttributes() override
  {
    return std::vector<AttributeInterface*>({
      static_cast<AttributeInterface*>(&mNumberOfPositions),
      static_cast<AttributeInterface*>(&mCurrentPosition),
      static_cast<AttributeInterface*>(&mMultiPressMax),
      static_cast<AttributeInterface*>(&mGeneratedCommandList),
      static_cast<AttributeInterface*>(&mAcceptedCommandList),
      static_cast<AttributeInterface*>(&mEventList),
      static_cast<AttributeInterface*>(&mAttributeList),
      static_cast<AttributeInterface*>(&mFeatureMap),
      static_cast<AttributeInterface*>(&mClusterRevision),
    });
  }


  Attribute<uint8_t> mNumberOfPositions;
  Attribute<uint8_t> mCurrentPosition;
  Attribute<uint8_t> mMultiPressMax;
  ListAttribute<std::vector<uint32_t>> mGeneratedCommandList;
  ListAttribute<std::vector<uint32_t>> mAcceptedCommandList;
  ListAttribute<std::vector<uint32_t>> mEventList;
  ListAttribute<std::vector<uint32_t>> mAttributeList;
  Attribute<uint32_t> mFeatureMap;
  Attribute<uint16_t> mClusterRevision;
};

}
