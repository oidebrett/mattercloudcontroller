#pragma once

#include "BridgeGlobalStructs.h"
#include "GeneratedClusters.h"

namespace clusters {
struct DescriptorCluster : public GeneratedCluster
{
  struct DeviceTypeStruct
  {
    CHIP_ERROR Decode(chip::TLV::TLVReader & reader)
    {
      chip::app::Clusters::Descriptor::Structs::DeviceTypeStruct::DecodableType t;
      CHIP_ERROR err = t.Decode(reader);
      if(err == CHIP_NO_ERROR) {
        deviceType = t.deviceType;
        revision = t.revision;
      }
      return err;
    }

    CHIP_ERROR Encode(chip::TLV::TLVWriter & writer, chip::TLV::Tag tag) const
    {
      chip::app::Clusters::Descriptor::Structs::DeviceTypeStruct::Type t;
      t.deviceType = deviceType;
      t.revision = revision;
      return t.Encode(writer, tag);
    }

    static constexpr bool kIsFabricScoped = false;
    uint32_t deviceType;
    uint16_t revision;
  };

  DescriptorCluster() :
      mDeviceTypeList(chip::CharSpan("deviceTypeList"), 0, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, sizeof(DeviceTypeStruct)),
      mServerList(chip::CharSpan("serverList"), 1, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mClientList(chip::CharSpan("clientList"), 2, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mPartsList(chip::CharSpan("partsList"), 3, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 2),
      mGeneratedCommandList(chip::CharSpan("generatedCommandList"), 65528, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mAcceptedCommandList(chip::CharSpan("acceptedCommandList"), 65529, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mEventList(chip::CharSpan("eventList"), 65530, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mAttributeList(chip::CharSpan("attributeList"), 65531, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mFeatureMap(chip::CharSpan("featureMap"), 65532, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_BITMAP32_ATTRIBUTE_TYPE, 4),
      mClusterRevision(chip::CharSpan("clusterRevision"), 65533, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2, ZCL_DESCRIPTOR_CLUSTER_REVISION)
  {
  }

  static constexpr uint32_t kClusterId =29;
  chip::ClusterId GetClusterId() override { return kClusterId; }

  std::vector<AttributeInterface*> GetAttributes() override
  {
    return std::vector<AttributeInterface*>({
      static_cast<AttributeInterface*>(&mDeviceTypeList),
      static_cast<AttributeInterface*>(&mServerList),
      static_cast<AttributeInterface*>(&mClientList),
      static_cast<AttributeInterface*>(&mPartsList),
      static_cast<AttributeInterface*>(&mGeneratedCommandList),
      static_cast<AttributeInterface*>(&mAcceptedCommandList),
      static_cast<AttributeInterface*>(&mEventList),
      static_cast<AttributeInterface*>(&mAttributeList),
      static_cast<AttributeInterface*>(&mFeatureMap),
      static_cast<AttributeInterface*>(&mClusterRevision),
    });
  }


  ListAttribute<std::vector<DeviceTypeStruct>> mDeviceTypeList;
  ListAttribute<std::vector<uint32_t>> mServerList;
  ListAttribute<std::vector<uint32_t>> mClientList;
  ListAttribute<std::vector<uint16_t>> mPartsList;
  ListAttribute<std::vector<uint32_t>> mGeneratedCommandList;
  ListAttribute<std::vector<uint32_t>> mAcceptedCommandList;
  ListAttribute<std::vector<uint32_t>> mEventList;
  ListAttribute<std::vector<uint32_t>> mAttributeList;
  Attribute<uint32_t> mFeatureMap;
  Attribute<uint16_t> mClusterRevision;
};

}
