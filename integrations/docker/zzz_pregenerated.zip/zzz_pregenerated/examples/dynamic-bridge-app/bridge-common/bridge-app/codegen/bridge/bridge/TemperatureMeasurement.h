#pragma once

#include "BridgeGlobalStructs.h"
#include "GeneratedClusters.h"

namespace clusters {
struct TemperatureMeasurementCluster : public GeneratedCluster
{

  TemperatureMeasurementCluster() :
      mMeasuredValue(chip::CharSpan("measuredValue"), 0, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16S_ATTRIBUTE_TYPE, 2),
      mMinMeasuredValue(chip::CharSpan("minMeasuredValue"), 1, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16S_ATTRIBUTE_TYPE, 2),
      mMaxMeasuredValue(chip::CharSpan("maxMeasuredValue"), 2, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16S_ATTRIBUTE_TYPE, 2),
      mGeneratedCommandList(chip::CharSpan("generatedCommandList"), 65528, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mAcceptedCommandList(chip::CharSpan("acceptedCommandList"), 65529, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mEventList(chip::CharSpan("eventList"), 65530, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mAttributeList(chip::CharSpan("attributeList"), 65531, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_ARRAY_ATTRIBUTE_TYPE, 4),
      mFeatureMap(chip::CharSpan("featureMap"), 65532, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_BITMAP32_ATTRIBUTE_TYPE, 4),
      mClusterRevision(chip::CharSpan("clusterRevision"), 65533, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2, ZCL_TEMPERATURE_MEASUREMENT_CLUSTER_REVISION)
  {
  }

  static constexpr uint32_t kClusterId =1026;
  chip::ClusterId GetClusterId() override { return kClusterId; }

  std::vector<AttributeInterface*> GetAttributes() override
  {
    return std::vector<AttributeInterface*>({
      static_cast<AttributeInterface*>(&mMeasuredValue),
      static_cast<AttributeInterface*>(&mMinMeasuredValue),
      static_cast<AttributeInterface*>(&mMaxMeasuredValue),
      static_cast<AttributeInterface*>(&mGeneratedCommandList),
      static_cast<AttributeInterface*>(&mAcceptedCommandList),
      static_cast<AttributeInterface*>(&mEventList),
      static_cast<AttributeInterface*>(&mAttributeList),
      static_cast<AttributeInterface*>(&mFeatureMap),
      static_cast<AttributeInterface*>(&mClusterRevision),
    });
  }


  Attribute<::chip::app::DataModel::Nullable<int16_t>> mMeasuredValue;
  Attribute<::chip::app::DataModel::Nullable<int16_t>> mMinMeasuredValue;
  Attribute<::chip::app::DataModel::Nullable<int16_t>> mMaxMeasuredValue;
  ListAttribute<std::vector<uint32_t>> mGeneratedCommandList;
  ListAttribute<std::vector<uint32_t>> mAcceptedCommandList;
  ListAttribute<std::vector<uint32_t>> mEventList;
  ListAttribute<std::vector<uint32_t>> mAttributeList;
  Attribute<uint32_t> mFeatureMap;
  Attribute<uint16_t> mClusterRevision;
};

}
