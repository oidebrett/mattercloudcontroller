/*
 *
 *    Copyright (c) 2023 Project CHIP Authors
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
#include <jni/CHIPCallbackTypes.h>

#include <controller/java/AndroidCallbacks.h>
#include <jni.h>
#include <lib/support/ErrorStr.h>
#include <lib/support/JniReferences.h>
#include <zap-generated/CHIPClientCallbacks.h>

class CHIPBooleanAttributeCallback : public chip::Callback::Callback<BooleanAttributeCallback>
{
public:
    CHIPBooleanAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBooleanAttributeCallback();

    static void maybeDestroy(CHIPBooleanAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBooleanAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, bool value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBooleanAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPCharStringAttributeCallback : public chip::Callback::Callback<CharStringAttributeCallback>
{
public:
    CHIPCharStringAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPCharStringAttributeCallback();

    static void maybeDestroy(CHIPCharStringAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPCharStringAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::CharSpan value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPCharStringAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPDoubleAttributeCallback : public chip::Callback::Callback<DoubleAttributeCallback>
{
public:
    CHIPDoubleAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoubleAttributeCallback();

    static void maybeDestroy(CHIPDoubleAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoubleAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, double value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoubleAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPFloatAttributeCallback : public chip::Callback::Callback<FloatAttributeCallback>
{
public:
    CHIPFloatAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFloatAttributeCallback();

    static void maybeDestroy(CHIPFloatAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFloatAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, float value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFloatAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPInt8sAttributeCallback : public chip::Callback::Callback<Int8sAttributeCallback>
{
public:
    CHIPInt8sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPInt8sAttributeCallback();

    static void maybeDestroy(CHIPInt8sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPInt8sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, int8_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPInt8sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPInt8uAttributeCallback : public chip::Callback::Callback<Int8uAttributeCallback>
{
public:
    CHIPInt8uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPInt8uAttributeCallback();

    static void maybeDestroy(CHIPInt8uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPInt8uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, uint8_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPInt8uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPInt16sAttributeCallback : public chip::Callback::Callback<Int16sAttributeCallback>
{
public:
    CHIPInt16sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPInt16sAttributeCallback();

    static void maybeDestroy(CHIPInt16sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPInt16sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, int16_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPInt16sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPInt16uAttributeCallback : public chip::Callback::Callback<Int16uAttributeCallback>
{
public:
    CHIPInt16uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPInt16uAttributeCallback();

    static void maybeDestroy(CHIPInt16uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPInt16uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, uint16_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPInt16uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPInt32sAttributeCallback : public chip::Callback::Callback<Int32sAttributeCallback>
{
public:
    CHIPInt32sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPInt32sAttributeCallback();

    static void maybeDestroy(CHIPInt32sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPInt32sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, int32_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPInt32sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPInt32uAttributeCallback : public chip::Callback::Callback<Int32uAttributeCallback>
{
public:
    CHIPInt32uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPInt32uAttributeCallback();

    static void maybeDestroy(CHIPInt32uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPInt32uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, uint32_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPInt32uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPInt64sAttributeCallback : public chip::Callback::Callback<Int64sAttributeCallback>
{
public:
    CHIPInt64sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPInt64sAttributeCallback();

    static void maybeDestroy(CHIPInt64sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPInt64sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, int64_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPInt64sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPInt64uAttributeCallback : public chip::Callback::Callback<Int64uAttributeCallback>
{
public:
    CHIPInt64uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPInt64uAttributeCallback();

    static void maybeDestroy(CHIPInt64uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPInt64uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, uint64_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPInt64uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};
class CHIPOctetStringAttributeCallback : public chip::Callback::Callback<OctetStringAttributeCallback>
{
public:
    CHIPOctetStringAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOctetStringAttributeCallback();

    static void maybeDestroy(CHIPOctetStringAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOctetStringAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::ByteSpan value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOctetStringAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};



  
class CHIPIdentifyGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPIdentifyClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPIdentifyGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIdentifyGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPIdentifyGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIdentifyGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIdentifyGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIdentifyAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPIdentifyClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPIdentifyAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIdentifyAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPIdentifyAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIdentifyAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIdentifyAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIdentifyEventListAttributeCallback : public chip::Callback::Callback<CHIPIdentifyClusterEventListAttributeCallbackType>
{
public:
    CHIPIdentifyEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIdentifyEventListAttributeCallback();

    static void maybeDestroy(CHIPIdentifyEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIdentifyEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIdentifyEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIdentifyAttributeListAttributeCallback : public chip::Callback::Callback<CHIPIdentifyClusterAttributeListAttributeCallbackType>
{
public:
    CHIPIdentifyAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIdentifyAttributeListAttributeCallback();

    static void maybeDestroy(CHIPIdentifyAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIdentifyAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIdentifyAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPGroupsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPGroupsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPGroupsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPGroupsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGroupsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPGroupsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPGroupsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPGroupsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGroupsEventListAttributeCallback : public chip::Callback::Callback<CHIPGroupsClusterEventListAttributeCallbackType>
{
public:
    CHIPGroupsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupsEventListAttributeCallback();

    static void maybeDestroy(CHIPGroupsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGroupsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPGroupsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPGroupsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPGroupsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPScenesCurrentGroupAttributeCallback : public chip::Callback::Callback<CHIPScenesClusterCurrentGroupAttributeCallbackType>
{
public:
    CHIPScenesCurrentGroupAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPScenesCurrentGroupAttributeCallback();

    static void maybeDestroy(CHIPScenesCurrentGroupAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPScenesCurrentGroupAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::GroupId value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPScenesCurrentGroupAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPScenesLastConfiguredByAttributeCallback : public chip::Callback::Callback<CHIPScenesClusterLastConfiguredByAttributeCallbackType>
{
public:
    CHIPScenesLastConfiguredByAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPScenesLastConfiguredByAttributeCallback();

    static void maybeDestroy(CHIPScenesLastConfiguredByAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPScenesLastConfiguredByAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::NodeId> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPScenesLastConfiguredByAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPScenesGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPScenesClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPScenesGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPScenesGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPScenesGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPScenesGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPScenesGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPScenesAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPScenesClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPScenesAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPScenesAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPScenesAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPScenesAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPScenesAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPScenesEventListAttributeCallback : public chip::Callback::Callback<CHIPScenesClusterEventListAttributeCallbackType>
{
public:
    CHIPScenesEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPScenesEventListAttributeCallback();

    static void maybeDestroy(CHIPScenesEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPScenesEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPScenesEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPScenesAttributeListAttributeCallback : public chip::Callback::Callback<CHIPScenesClusterAttributeListAttributeCallbackType>
{
public:
    CHIPScenesAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPScenesAttributeListAttributeCallback();

    static void maybeDestroy(CHIPScenesAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPScenesAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPScenesAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPOnOffStartUpOnOffAttributeCallback : public chip::Callback::Callback<CHIPOnOffClusterStartUpOnOffAttributeCallbackType>
{
public:
    CHIPOnOffStartUpOnOffAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffStartUpOnOffAttributeCallback();

    static void maybeDestroy(CHIPOnOffStartUpOnOffAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffStartUpOnOffAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::OnOff::OnOffStartUpOnOff> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffStartUpOnOffAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOnOffGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOnOffClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPOnOffGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOnOffGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOnOffAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOnOffClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPOnOffAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOnOffAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOnOffEventListAttributeCallback : public chip::Callback::Callback<CHIPOnOffClusterEventListAttributeCallbackType>
{
public:
    CHIPOnOffEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffEventListAttributeCallback();

    static void maybeDestroy(CHIPOnOffEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOnOffAttributeListAttributeCallback : public chip::Callback::Callback<CHIPOnOffClusterAttributeListAttributeCallbackType>
{
public:
    CHIPOnOffAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffAttributeListAttributeCallback();

    static void maybeDestroy(CHIPOnOffAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPOnOffSwitchConfigurationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOnOffSwitchConfigurationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPOnOffSwitchConfigurationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffSwitchConfigurationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOnOffSwitchConfigurationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffSwitchConfigurationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffSwitchConfigurationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOnOffSwitchConfigurationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOnOffSwitchConfigurationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPOnOffSwitchConfigurationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffSwitchConfigurationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOnOffSwitchConfigurationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffSwitchConfigurationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffSwitchConfigurationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOnOffSwitchConfigurationEventListAttributeCallback : public chip::Callback::Callback<CHIPOnOffSwitchConfigurationClusterEventListAttributeCallbackType>
{
public:
    CHIPOnOffSwitchConfigurationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffSwitchConfigurationEventListAttributeCallback();

    static void maybeDestroy(CHIPOnOffSwitchConfigurationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffSwitchConfigurationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffSwitchConfigurationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOnOffSwitchConfigurationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPOnOffSwitchConfigurationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPOnOffSwitchConfigurationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOnOffSwitchConfigurationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPOnOffSwitchConfigurationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOnOffSwitchConfigurationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOnOffSwitchConfigurationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPLevelControlCurrentLevelAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterCurrentLevelAttributeCallbackType>
{
public:
    CHIPLevelControlCurrentLevelAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlCurrentLevelAttributeCallback();

    static void maybeDestroy(CHIPLevelControlCurrentLevelAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlCurrentLevelAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlCurrentLevelAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlOptionsAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterOptionsAttributeCallbackType>
{
public:
    CHIPLevelControlOptionsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlOptionsAttributeCallback();

    static void maybeDestroy(CHIPLevelControlOptionsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlOptionsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::LevelControl::LevelControlOptions> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlOptionsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlOnLevelAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterOnLevelAttributeCallbackType>
{
public:
    CHIPLevelControlOnLevelAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlOnLevelAttributeCallback();

    static void maybeDestroy(CHIPLevelControlOnLevelAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlOnLevelAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlOnLevelAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlOnTransitionTimeAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterOnTransitionTimeAttributeCallbackType>
{
public:
    CHIPLevelControlOnTransitionTimeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlOnTransitionTimeAttributeCallback();

    static void maybeDestroy(CHIPLevelControlOnTransitionTimeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlOnTransitionTimeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlOnTransitionTimeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlOffTransitionTimeAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterOffTransitionTimeAttributeCallbackType>
{
public:
    CHIPLevelControlOffTransitionTimeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlOffTransitionTimeAttributeCallback();

    static void maybeDestroy(CHIPLevelControlOffTransitionTimeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlOffTransitionTimeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlOffTransitionTimeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlDefaultMoveRateAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterDefaultMoveRateAttributeCallbackType>
{
public:
    CHIPLevelControlDefaultMoveRateAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlDefaultMoveRateAttributeCallback();

    static void maybeDestroy(CHIPLevelControlDefaultMoveRateAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlDefaultMoveRateAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlDefaultMoveRateAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlStartUpCurrentLevelAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterStartUpCurrentLevelAttributeCallbackType>
{
public:
    CHIPLevelControlStartUpCurrentLevelAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlStartUpCurrentLevelAttributeCallback();

    static void maybeDestroy(CHIPLevelControlStartUpCurrentLevelAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlStartUpCurrentLevelAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlStartUpCurrentLevelAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPLevelControlGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPLevelControlGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPLevelControlAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPLevelControlAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlEventListAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterEventListAttributeCallbackType>
{
public:
    CHIPLevelControlEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlEventListAttributeCallback();

    static void maybeDestroy(CHIPLevelControlEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLevelControlAttributeListAttributeCallback : public chip::Callback::Callback<CHIPLevelControlClusterAttributeListAttributeCallbackType>
{
public:
    CHIPLevelControlAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLevelControlAttributeListAttributeCallback();

    static void maybeDestroy(CHIPLevelControlAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLevelControlAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLevelControlAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPBinaryInputBasicGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBinaryInputBasicClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPBinaryInputBasicGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBinaryInputBasicGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBinaryInputBasicGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBinaryInputBasicGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBinaryInputBasicGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBinaryInputBasicAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBinaryInputBasicClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPBinaryInputBasicAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBinaryInputBasicAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBinaryInputBasicAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBinaryInputBasicAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBinaryInputBasicAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBinaryInputBasicEventListAttributeCallback : public chip::Callback::Callback<CHIPBinaryInputBasicClusterEventListAttributeCallbackType>
{
public:
    CHIPBinaryInputBasicEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBinaryInputBasicEventListAttributeCallback();

    static void maybeDestroy(CHIPBinaryInputBasicEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBinaryInputBasicEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBinaryInputBasicEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBinaryInputBasicAttributeListAttributeCallback : public chip::Callback::Callback<CHIPBinaryInputBasicClusterAttributeListAttributeCallbackType>
{
public:
    CHIPBinaryInputBasicAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBinaryInputBasicAttributeListAttributeCallback();

    static void maybeDestroy(CHIPBinaryInputBasicAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBinaryInputBasicAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBinaryInputBasicAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPDescriptorDeviceTypeListAttributeCallback : public chip::Callback::Callback<CHIPDescriptorClusterDeviceTypeListAttributeCallbackType>
{
public:
    CHIPDescriptorDeviceTypeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDescriptorDeviceTypeListAttributeCallback();

    static void maybeDestroy(CHIPDescriptorDeviceTypeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDescriptorDeviceTypeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::Descriptor::Structs::DeviceTypeStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDescriptorDeviceTypeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDescriptorServerListAttributeCallback : public chip::Callback::Callback<CHIPDescriptorClusterServerListAttributeCallbackType>
{
public:
    CHIPDescriptorServerListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDescriptorServerListAttributeCallback();

    static void maybeDestroy(CHIPDescriptorServerListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDescriptorServerListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::ClusterId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDescriptorServerListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDescriptorClientListAttributeCallback : public chip::Callback::Callback<CHIPDescriptorClusterClientListAttributeCallbackType>
{
public:
    CHIPDescriptorClientListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDescriptorClientListAttributeCallback();

    static void maybeDestroy(CHIPDescriptorClientListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDescriptorClientListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::ClusterId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDescriptorClientListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDescriptorPartsListAttributeCallback : public chip::Callback::Callback<CHIPDescriptorClusterPartsListAttributeCallbackType>
{
public:
    CHIPDescriptorPartsListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDescriptorPartsListAttributeCallback();

    static void maybeDestroy(CHIPDescriptorPartsListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDescriptorPartsListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EndpointId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDescriptorPartsListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDescriptorGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPDescriptorClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPDescriptorGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDescriptorGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPDescriptorGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDescriptorGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDescriptorGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDescriptorAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPDescriptorClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPDescriptorAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDescriptorAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPDescriptorAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDescriptorAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDescriptorAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDescriptorEventListAttributeCallback : public chip::Callback::Callback<CHIPDescriptorClusterEventListAttributeCallbackType>
{
public:
    CHIPDescriptorEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDescriptorEventListAttributeCallback();

    static void maybeDestroy(CHIPDescriptorEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDescriptorEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDescriptorEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDescriptorAttributeListAttributeCallback : public chip::Callback::Callback<CHIPDescriptorClusterAttributeListAttributeCallbackType>
{
public:
    CHIPDescriptorAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDescriptorAttributeListAttributeCallback();

    static void maybeDestroy(CHIPDescriptorAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDescriptorAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDescriptorAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPBindingBindingAttributeCallback : public chip::Callback::Callback<CHIPBindingClusterBindingAttributeCallbackType>
{
public:
    CHIPBindingBindingAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBindingBindingAttributeCallback();

    static void maybeDestroy(CHIPBindingBindingAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBindingBindingAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::Binding::Structs::TargetStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBindingBindingAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBindingGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBindingClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPBindingGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBindingGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBindingGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBindingGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBindingGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBindingAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBindingClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPBindingAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBindingAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBindingAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBindingAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBindingAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBindingEventListAttributeCallback : public chip::Callback::Callback<CHIPBindingClusterEventListAttributeCallbackType>
{
public:
    CHIPBindingEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBindingEventListAttributeCallback();

    static void maybeDestroy(CHIPBindingEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBindingEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBindingEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBindingAttributeListAttributeCallback : public chip::Callback::Callback<CHIPBindingClusterAttributeListAttributeCallbackType>
{
public:
    CHIPBindingAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBindingAttributeListAttributeCallback();

    static void maybeDestroy(CHIPBindingAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBindingAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBindingAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPAccessControlAclAttributeCallback : public chip::Callback::Callback<CHIPAccessControlClusterAclAttributeCallbackType>
{
public:
    CHIPAccessControlAclAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccessControlAclAttributeCallback();

    static void maybeDestroy(CHIPAccessControlAclAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccessControlAclAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::AccessControl::Structs::AccessControlEntryStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccessControlAclAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAccessControlExtensionAttributeCallback : public chip::Callback::Callback<CHIPAccessControlClusterExtensionAttributeCallbackType>
{
public:
    CHIPAccessControlExtensionAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccessControlExtensionAttributeCallback();

    static void maybeDestroy(CHIPAccessControlExtensionAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccessControlExtensionAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::AccessControl::Structs::AccessControlExtensionStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccessControlExtensionAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAccessControlGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPAccessControlClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPAccessControlGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccessControlGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPAccessControlGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccessControlGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccessControlGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAccessControlAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPAccessControlClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPAccessControlAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccessControlAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPAccessControlAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccessControlAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccessControlAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAccessControlEventListAttributeCallback : public chip::Callback::Callback<CHIPAccessControlClusterEventListAttributeCallbackType>
{
public:
    CHIPAccessControlEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccessControlEventListAttributeCallback();

    static void maybeDestroy(CHIPAccessControlEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccessControlEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccessControlEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAccessControlAttributeListAttributeCallback : public chip::Callback::Callback<CHIPAccessControlClusterAttributeListAttributeCallbackType>
{
public:
    CHIPAccessControlAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccessControlAttributeListAttributeCallback();

    static void maybeDestroy(CHIPAccessControlAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccessControlAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccessControlAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPActionsActionListAttributeCallback : public chip::Callback::Callback<CHIPActionsClusterActionListAttributeCallbackType>
{
public:
    CHIPActionsActionListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPActionsActionListAttributeCallback();

    static void maybeDestroy(CHIPActionsActionListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPActionsActionListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::Actions::Structs::ActionStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPActionsActionListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPActionsEndpointListsAttributeCallback : public chip::Callback::Callback<CHIPActionsClusterEndpointListsAttributeCallbackType>
{
public:
    CHIPActionsEndpointListsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPActionsEndpointListsAttributeCallback();

    static void maybeDestroy(CHIPActionsEndpointListsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPActionsEndpointListsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::Actions::Structs::EndpointListStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPActionsEndpointListsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPActionsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPActionsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPActionsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPActionsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPActionsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPActionsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPActionsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPActionsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPActionsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPActionsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPActionsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPActionsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPActionsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPActionsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPActionsEventListAttributeCallback : public chip::Callback::Callback<CHIPActionsClusterEventListAttributeCallbackType>
{
public:
    CHIPActionsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPActionsEventListAttributeCallback();

    static void maybeDestroy(CHIPActionsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPActionsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPActionsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPActionsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPActionsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPActionsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPActionsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPActionsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPActionsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPActionsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPBasicInformationVendorIDAttributeCallback : public chip::Callback::Callback<CHIPBasicInformationClusterVendorIDAttributeCallbackType>
{
public:
    CHIPBasicInformationVendorIDAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBasicInformationVendorIDAttributeCallback();

    static void maybeDestroy(CHIPBasicInformationVendorIDAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBasicInformationVendorIDAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::VendorId value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBasicInformationVendorIDAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBasicInformationCapabilityMinimaAttributeCallback : public chip::Callback::Callback<CHIPBasicInformationClusterCapabilityMinimaAttributeCallbackType>
{
public:
    CHIPBasicInformationCapabilityMinimaAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBasicInformationCapabilityMinimaAttributeCallback();

    static void maybeDestroy(CHIPBasicInformationCapabilityMinimaAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBasicInformationCapabilityMinimaAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::BasicInformation::Structs::CapabilityMinimaStruct::DecodableType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBasicInformationCapabilityMinimaAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBasicInformationProductAppearanceAttributeCallback : public chip::Callback::Callback<CHIPBasicInformationClusterProductAppearanceAttributeCallbackType>
{
public:
    CHIPBasicInformationProductAppearanceAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBasicInformationProductAppearanceAttributeCallback();

    static void maybeDestroy(CHIPBasicInformationProductAppearanceAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBasicInformationProductAppearanceAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::BasicInformation::Structs::ProductAppearanceStruct::DecodableType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBasicInformationProductAppearanceAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBasicInformationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBasicInformationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPBasicInformationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBasicInformationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBasicInformationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBasicInformationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBasicInformationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBasicInformationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBasicInformationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPBasicInformationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBasicInformationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBasicInformationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBasicInformationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBasicInformationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBasicInformationEventListAttributeCallback : public chip::Callback::Callback<CHIPBasicInformationClusterEventListAttributeCallbackType>
{
public:
    CHIPBasicInformationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBasicInformationEventListAttributeCallback();

    static void maybeDestroy(CHIPBasicInformationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBasicInformationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBasicInformationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBasicInformationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPBasicInformationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPBasicInformationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBasicInformationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPBasicInformationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBasicInformationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBasicInformationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPOtaSoftwareUpdateProviderGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateProviderClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateProviderGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateProviderGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateProviderGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateProviderGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateProviderGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateProviderAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateProviderClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateProviderAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateProviderAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateProviderAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateProviderAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateProviderAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateProviderEventListAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateProviderClusterEventListAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateProviderEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateProviderEventListAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateProviderEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateProviderEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateProviderEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateProviderAttributeListAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateProviderClusterAttributeListAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateProviderAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateProviderAttributeListAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateProviderAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateProviderAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateProviderAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPOtaSoftwareUpdateRequestorDefaultOTAProvidersAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateRequestorClusterDefaultOTAProvidersAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateRequestorDefaultOTAProvidersAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateRequestorDefaultOTAProvidersAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateRequestorDefaultOTAProvidersAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateRequestorDefaultOTAProvidersAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::OtaSoftwareUpdateRequestor::Structs::ProviderLocation::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateRequestorDefaultOTAProvidersAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateRequestorUpdateStateAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateRequestorClusterUpdateStateAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateRequestorUpdateStateAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateRequestorUpdateStateAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateRequestorUpdateStateAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateRequestorUpdateStateAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::OtaSoftwareUpdateRequestor::OTAUpdateStateEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateRequestorUpdateStateAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateRequestorUpdateStateProgressAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateRequestorClusterUpdateStateProgressAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateRequestorUpdateStateProgressAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateRequestorUpdateStateProgressAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateRequestorUpdateStateProgressAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateRequestorUpdateStateProgressAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateRequestorUpdateStateProgressAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateRequestorGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateRequestorClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateRequestorGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateRequestorGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateRequestorGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateRequestorGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateRequestorGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateRequestorAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateRequestorClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateRequestorAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateRequestorAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateRequestorAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateRequestorAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateRequestorAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateRequestorEventListAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateRequestorClusterEventListAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateRequestorEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateRequestorEventListAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateRequestorEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateRequestorEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateRequestorEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOtaSoftwareUpdateRequestorAttributeListAttributeCallback : public chip::Callback::Callback<CHIPOtaSoftwareUpdateRequestorClusterAttributeListAttributeCallbackType>
{
public:
    CHIPOtaSoftwareUpdateRequestorAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOtaSoftwareUpdateRequestorAttributeListAttributeCallback();

    static void maybeDestroy(CHIPOtaSoftwareUpdateRequestorAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOtaSoftwareUpdateRequestorAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOtaSoftwareUpdateRequestorAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPLocalizationConfigurationSupportedLocalesAttributeCallback : public chip::Callback::Callback<CHIPLocalizationConfigurationClusterSupportedLocalesAttributeCallbackType>
{
public:
    CHIPLocalizationConfigurationSupportedLocalesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLocalizationConfigurationSupportedLocalesAttributeCallback();

    static void maybeDestroy(CHIPLocalizationConfigurationSupportedLocalesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLocalizationConfigurationSupportedLocalesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CharSpan> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLocalizationConfigurationSupportedLocalesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLocalizationConfigurationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPLocalizationConfigurationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPLocalizationConfigurationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLocalizationConfigurationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPLocalizationConfigurationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLocalizationConfigurationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLocalizationConfigurationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLocalizationConfigurationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPLocalizationConfigurationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPLocalizationConfigurationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLocalizationConfigurationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPLocalizationConfigurationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLocalizationConfigurationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLocalizationConfigurationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLocalizationConfigurationEventListAttributeCallback : public chip::Callback::Callback<CHIPLocalizationConfigurationClusterEventListAttributeCallbackType>
{
public:
    CHIPLocalizationConfigurationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLocalizationConfigurationEventListAttributeCallback();

    static void maybeDestroy(CHIPLocalizationConfigurationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLocalizationConfigurationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLocalizationConfigurationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLocalizationConfigurationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPLocalizationConfigurationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPLocalizationConfigurationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLocalizationConfigurationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPLocalizationConfigurationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLocalizationConfigurationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLocalizationConfigurationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPTimeFormatLocalizationHourFormatAttributeCallback : public chip::Callback::Callback<CHIPTimeFormatLocalizationClusterHourFormatAttributeCallbackType>
{
public:
    CHIPTimeFormatLocalizationHourFormatAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTimeFormatLocalizationHourFormatAttributeCallback();

    static void maybeDestroy(CHIPTimeFormatLocalizationHourFormatAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTimeFormatLocalizationHourFormatAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::TimeFormatLocalization::HourFormatEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTimeFormatLocalizationHourFormatAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTimeFormatLocalizationActiveCalendarTypeAttributeCallback : public chip::Callback::Callback<CHIPTimeFormatLocalizationClusterActiveCalendarTypeAttributeCallbackType>
{
public:
    CHIPTimeFormatLocalizationActiveCalendarTypeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTimeFormatLocalizationActiveCalendarTypeAttributeCallback();

    static void maybeDestroy(CHIPTimeFormatLocalizationActiveCalendarTypeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTimeFormatLocalizationActiveCalendarTypeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::TimeFormatLocalization::CalendarTypeEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTimeFormatLocalizationActiveCalendarTypeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTimeFormatLocalizationSupportedCalendarTypesAttributeCallback : public chip::Callback::Callback<CHIPTimeFormatLocalizationClusterSupportedCalendarTypesAttributeCallbackType>
{
public:
    CHIPTimeFormatLocalizationSupportedCalendarTypesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTimeFormatLocalizationSupportedCalendarTypesAttributeCallback();

    static void maybeDestroy(CHIPTimeFormatLocalizationSupportedCalendarTypesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTimeFormatLocalizationSupportedCalendarTypesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::TimeFormatLocalization::CalendarTypeEnum> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTimeFormatLocalizationSupportedCalendarTypesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTimeFormatLocalizationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPTimeFormatLocalizationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPTimeFormatLocalizationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTimeFormatLocalizationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPTimeFormatLocalizationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTimeFormatLocalizationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTimeFormatLocalizationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTimeFormatLocalizationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPTimeFormatLocalizationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPTimeFormatLocalizationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTimeFormatLocalizationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPTimeFormatLocalizationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTimeFormatLocalizationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTimeFormatLocalizationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTimeFormatLocalizationEventListAttributeCallback : public chip::Callback::Callback<CHIPTimeFormatLocalizationClusterEventListAttributeCallbackType>
{
public:
    CHIPTimeFormatLocalizationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTimeFormatLocalizationEventListAttributeCallback();

    static void maybeDestroy(CHIPTimeFormatLocalizationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTimeFormatLocalizationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTimeFormatLocalizationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTimeFormatLocalizationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPTimeFormatLocalizationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPTimeFormatLocalizationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTimeFormatLocalizationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPTimeFormatLocalizationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTimeFormatLocalizationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTimeFormatLocalizationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPUnitLocalizationTemperatureUnitAttributeCallback : public chip::Callback::Callback<CHIPUnitLocalizationClusterTemperatureUnitAttributeCallbackType>
{
public:
    CHIPUnitLocalizationTemperatureUnitAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitLocalizationTemperatureUnitAttributeCallback();

    static void maybeDestroy(CHIPUnitLocalizationTemperatureUnitAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitLocalizationTemperatureUnitAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::UnitLocalization::TempUnitEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitLocalizationTemperatureUnitAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitLocalizationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPUnitLocalizationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPUnitLocalizationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitLocalizationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPUnitLocalizationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitLocalizationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitLocalizationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitLocalizationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPUnitLocalizationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPUnitLocalizationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitLocalizationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPUnitLocalizationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitLocalizationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitLocalizationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitLocalizationEventListAttributeCallback : public chip::Callback::Callback<CHIPUnitLocalizationClusterEventListAttributeCallbackType>
{
public:
    CHIPUnitLocalizationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitLocalizationEventListAttributeCallback();

    static void maybeDestroy(CHIPUnitLocalizationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitLocalizationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitLocalizationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitLocalizationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPUnitLocalizationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPUnitLocalizationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitLocalizationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPUnitLocalizationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitLocalizationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitLocalizationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPPowerSourceConfigurationSourcesAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceConfigurationClusterSourcesAttributeCallbackType>
{
public:
    CHIPPowerSourceConfigurationSourcesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceConfigurationSourcesAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceConfigurationSourcesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceConfigurationSourcesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<uint8_t> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceConfigurationSourcesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceConfigurationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceConfigurationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPPowerSourceConfigurationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceConfigurationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceConfigurationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceConfigurationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceConfigurationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceConfigurationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceConfigurationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPPowerSourceConfigurationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceConfigurationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceConfigurationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceConfigurationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceConfigurationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceConfigurationEventListAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceConfigurationClusterEventListAttributeCallbackType>
{
public:
    CHIPPowerSourceConfigurationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceConfigurationEventListAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceConfigurationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceConfigurationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceConfigurationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceConfigurationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceConfigurationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPPowerSourceConfigurationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceConfigurationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceConfigurationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceConfigurationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceConfigurationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPPowerSourceStatusAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterStatusAttributeCallbackType>
{
public:
    CHIPPowerSourceStatusAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceStatusAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceStatusAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceStatusAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PowerSource::PowerSourceStatusEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceStatusAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceWiredAssessedInputVoltageAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterWiredAssessedInputVoltageAttributeCallbackType>
{
public:
    CHIPPowerSourceWiredAssessedInputVoltageAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceWiredAssessedInputVoltageAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceWiredAssessedInputVoltageAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceWiredAssessedInputVoltageAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceWiredAssessedInputVoltageAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceWiredAssessedInputFrequencyAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterWiredAssessedInputFrequencyAttributeCallbackType>
{
public:
    CHIPPowerSourceWiredAssessedInputFrequencyAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceWiredAssessedInputFrequencyAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceWiredAssessedInputFrequencyAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceWiredAssessedInputFrequencyAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceWiredAssessedInputFrequencyAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceWiredCurrentTypeAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterWiredCurrentTypeAttributeCallbackType>
{
public:
    CHIPPowerSourceWiredCurrentTypeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceWiredCurrentTypeAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceWiredCurrentTypeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceWiredCurrentTypeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PowerSource::WiredCurrentTypeEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceWiredCurrentTypeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceWiredAssessedCurrentAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterWiredAssessedCurrentAttributeCallbackType>
{
public:
    CHIPPowerSourceWiredAssessedCurrentAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceWiredAssessedCurrentAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceWiredAssessedCurrentAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceWiredAssessedCurrentAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceWiredAssessedCurrentAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceActiveWiredFaultsAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterActiveWiredFaultsAttributeCallbackType>
{
public:
    CHIPPowerSourceActiveWiredFaultsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceActiveWiredFaultsAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceActiveWiredFaultsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceActiveWiredFaultsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::PowerSource::WiredFaultEnum> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceActiveWiredFaultsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatVoltageAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatVoltageAttributeCallbackType>
{
public:
    CHIPPowerSourceBatVoltageAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatVoltageAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatVoltageAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatVoltageAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatVoltageAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatPercentRemainingAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatPercentRemainingAttributeCallbackType>
{
public:
    CHIPPowerSourceBatPercentRemainingAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatPercentRemainingAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatPercentRemainingAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatPercentRemainingAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatPercentRemainingAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatTimeRemainingAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatTimeRemainingAttributeCallbackType>
{
public:
    CHIPPowerSourceBatTimeRemainingAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatTimeRemainingAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatTimeRemainingAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatTimeRemainingAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatTimeRemainingAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatChargeLevelAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatChargeLevelAttributeCallbackType>
{
public:
    CHIPPowerSourceBatChargeLevelAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatChargeLevelAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatChargeLevelAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatChargeLevelAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PowerSource::BatChargeLevelEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatChargeLevelAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatReplaceabilityAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatReplaceabilityAttributeCallbackType>
{
public:
    CHIPPowerSourceBatReplaceabilityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatReplaceabilityAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatReplaceabilityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatReplaceabilityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PowerSource::BatReplaceabilityEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatReplaceabilityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceActiveBatFaultsAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterActiveBatFaultsAttributeCallbackType>
{
public:
    CHIPPowerSourceActiveBatFaultsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceActiveBatFaultsAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceActiveBatFaultsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceActiveBatFaultsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::PowerSource::BatFaultEnum> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceActiveBatFaultsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatCommonDesignationAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatCommonDesignationAttributeCallbackType>
{
public:
    CHIPPowerSourceBatCommonDesignationAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatCommonDesignationAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatCommonDesignationAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatCommonDesignationAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PowerSource::BatCommonDesignationEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatCommonDesignationAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatApprovedChemistryAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatApprovedChemistryAttributeCallbackType>
{
public:
    CHIPPowerSourceBatApprovedChemistryAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatApprovedChemistryAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatApprovedChemistryAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatApprovedChemistryAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PowerSource::BatApprovedChemistryEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatApprovedChemistryAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatChargeStateAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatChargeStateAttributeCallbackType>
{
public:
    CHIPPowerSourceBatChargeStateAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatChargeStateAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatChargeStateAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatChargeStateAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PowerSource::BatChargeStateEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatChargeStateAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatTimeToFullChargeAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatTimeToFullChargeAttributeCallbackType>
{
public:
    CHIPPowerSourceBatTimeToFullChargeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatTimeToFullChargeAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatTimeToFullChargeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatTimeToFullChargeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatTimeToFullChargeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceBatChargingCurrentAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterBatChargingCurrentAttributeCallbackType>
{
public:
    CHIPPowerSourceBatChargingCurrentAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceBatChargingCurrentAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceBatChargingCurrentAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceBatChargingCurrentAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceBatChargingCurrentAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceActiveBatChargeFaultsAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterActiveBatChargeFaultsAttributeCallbackType>
{
public:
    CHIPPowerSourceActiveBatChargeFaultsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceActiveBatChargeFaultsAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceActiveBatChargeFaultsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceActiveBatChargeFaultsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::PowerSource::BatChargeFaultEnum> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceActiveBatChargeFaultsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPPowerSourceGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPPowerSourceAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceEventListAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterEventListAttributeCallbackType>
{
public:
    CHIPPowerSourceEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceEventListAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPowerSourceAttributeListAttributeCallback : public chip::Callback::Callback<CHIPPowerSourceClusterAttributeListAttributeCallbackType>
{
public:
    CHIPPowerSourceAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPowerSourceAttributeListAttributeCallback();

    static void maybeDestroy(CHIPPowerSourceAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPowerSourceAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPowerSourceAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPGeneralCommissioningBasicCommissioningInfoAttributeCallback : public chip::Callback::Callback<CHIPGeneralCommissioningClusterBasicCommissioningInfoAttributeCallbackType>
{
public:
    CHIPGeneralCommissioningBasicCommissioningInfoAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralCommissioningBasicCommissioningInfoAttributeCallback();

    static void maybeDestroy(CHIPGeneralCommissioningBasicCommissioningInfoAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralCommissioningBasicCommissioningInfoAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::GeneralCommissioning::Structs::BasicCommissioningInfo::DecodableType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralCommissioningBasicCommissioningInfoAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralCommissioningRegulatoryConfigAttributeCallback : public chip::Callback::Callback<CHIPGeneralCommissioningClusterRegulatoryConfigAttributeCallbackType>
{
public:
    CHIPGeneralCommissioningRegulatoryConfigAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralCommissioningRegulatoryConfigAttributeCallback();

    static void maybeDestroy(CHIPGeneralCommissioningRegulatoryConfigAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralCommissioningRegulatoryConfigAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::GeneralCommissioning::RegulatoryLocationType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralCommissioningRegulatoryConfigAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralCommissioningLocationCapabilityAttributeCallback : public chip::Callback::Callback<CHIPGeneralCommissioningClusterLocationCapabilityAttributeCallbackType>
{
public:
    CHIPGeneralCommissioningLocationCapabilityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralCommissioningLocationCapabilityAttributeCallback();

    static void maybeDestroy(CHIPGeneralCommissioningLocationCapabilityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralCommissioningLocationCapabilityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::GeneralCommissioning::RegulatoryLocationType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralCommissioningLocationCapabilityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralCommissioningGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPGeneralCommissioningClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPGeneralCommissioningGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralCommissioningGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPGeneralCommissioningGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralCommissioningGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralCommissioningGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralCommissioningAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPGeneralCommissioningClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPGeneralCommissioningAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralCommissioningAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPGeneralCommissioningAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralCommissioningAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralCommissioningAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralCommissioningEventListAttributeCallback : public chip::Callback::Callback<CHIPGeneralCommissioningClusterEventListAttributeCallbackType>
{
public:
    CHIPGeneralCommissioningEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralCommissioningEventListAttributeCallback();

    static void maybeDestroy(CHIPGeneralCommissioningEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralCommissioningEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralCommissioningEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralCommissioningAttributeListAttributeCallback : public chip::Callback::Callback<CHIPGeneralCommissioningClusterAttributeListAttributeCallbackType>
{
public:
    CHIPGeneralCommissioningAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralCommissioningAttributeListAttributeCallback();

    static void maybeDestroy(CHIPGeneralCommissioningAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralCommissioningAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralCommissioningAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPNetworkCommissioningNetworksAttributeCallback : public chip::Callback::Callback<CHIPNetworkCommissioningClusterNetworksAttributeCallbackType>
{
public:
    CHIPNetworkCommissioningNetworksAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPNetworkCommissioningNetworksAttributeCallback();

    static void maybeDestroy(CHIPNetworkCommissioningNetworksAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPNetworkCommissioningNetworksAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::NetworkCommissioning::Structs::NetworkInfo::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPNetworkCommissioningNetworksAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPNetworkCommissioningLastNetworkingStatusAttributeCallback : public chip::Callback::Callback<CHIPNetworkCommissioningClusterLastNetworkingStatusAttributeCallbackType>
{
public:
    CHIPNetworkCommissioningLastNetworkingStatusAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPNetworkCommissioningLastNetworkingStatusAttributeCallback();

    static void maybeDestroy(CHIPNetworkCommissioningLastNetworkingStatusAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPNetworkCommissioningLastNetworkingStatusAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::NetworkCommissioning::NetworkCommissioningStatus> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPNetworkCommissioningLastNetworkingStatusAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPNetworkCommissioningLastNetworkIDAttributeCallback : public chip::Callback::Callback<CHIPNetworkCommissioningClusterLastNetworkIDAttributeCallbackType>
{
public:
    CHIPNetworkCommissioningLastNetworkIDAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPNetworkCommissioningLastNetworkIDAttributeCallback();

    static void maybeDestroy(CHIPNetworkCommissioningLastNetworkIDAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPNetworkCommissioningLastNetworkIDAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::ByteSpan> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPNetworkCommissioningLastNetworkIDAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPNetworkCommissioningLastConnectErrorValueAttributeCallback : public chip::Callback::Callback<CHIPNetworkCommissioningClusterLastConnectErrorValueAttributeCallbackType>
{
public:
    CHIPNetworkCommissioningLastConnectErrorValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPNetworkCommissioningLastConnectErrorValueAttributeCallback();

    static void maybeDestroy(CHIPNetworkCommissioningLastConnectErrorValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPNetworkCommissioningLastConnectErrorValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPNetworkCommissioningLastConnectErrorValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPNetworkCommissioningGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPNetworkCommissioningClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPNetworkCommissioningGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPNetworkCommissioningGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPNetworkCommissioningGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPNetworkCommissioningGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPNetworkCommissioningGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPNetworkCommissioningAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPNetworkCommissioningClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPNetworkCommissioningAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPNetworkCommissioningAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPNetworkCommissioningAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPNetworkCommissioningAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPNetworkCommissioningAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPNetworkCommissioningEventListAttributeCallback : public chip::Callback::Callback<CHIPNetworkCommissioningClusterEventListAttributeCallbackType>
{
public:
    CHIPNetworkCommissioningEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPNetworkCommissioningEventListAttributeCallback();

    static void maybeDestroy(CHIPNetworkCommissioningEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPNetworkCommissioningEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPNetworkCommissioningEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPNetworkCommissioningAttributeListAttributeCallback : public chip::Callback::Callback<CHIPNetworkCommissioningClusterAttributeListAttributeCallbackType>
{
public:
    CHIPNetworkCommissioningAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPNetworkCommissioningAttributeListAttributeCallback();

    static void maybeDestroy(CHIPNetworkCommissioningAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPNetworkCommissioningAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPNetworkCommissioningAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPDiagnosticLogsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPDiagnosticLogsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPDiagnosticLogsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDiagnosticLogsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPDiagnosticLogsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDiagnosticLogsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDiagnosticLogsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDiagnosticLogsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPDiagnosticLogsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPDiagnosticLogsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDiagnosticLogsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPDiagnosticLogsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDiagnosticLogsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDiagnosticLogsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDiagnosticLogsEventListAttributeCallback : public chip::Callback::Callback<CHIPDiagnosticLogsClusterEventListAttributeCallbackType>
{
public:
    CHIPDiagnosticLogsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDiagnosticLogsEventListAttributeCallback();

    static void maybeDestroy(CHIPDiagnosticLogsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDiagnosticLogsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDiagnosticLogsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDiagnosticLogsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPDiagnosticLogsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPDiagnosticLogsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDiagnosticLogsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPDiagnosticLogsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDiagnosticLogsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDiagnosticLogsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPGeneralDiagnosticsNetworkInterfacesAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterNetworkInterfacesAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsNetworkInterfacesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsNetworkInterfacesAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsNetworkInterfacesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsNetworkInterfacesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::GeneralDiagnostics::Structs::NetworkInterface::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsNetworkInterfacesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralDiagnosticsBootReasonAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterBootReasonAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsBootReasonAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsBootReasonAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsBootReasonAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsBootReasonAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::GeneralDiagnostics::BootReasonEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsBootReasonAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralDiagnosticsActiveHardwareFaultsAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterActiveHardwareFaultsAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsActiveHardwareFaultsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsActiveHardwareFaultsAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsActiveHardwareFaultsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsActiveHardwareFaultsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::GeneralDiagnostics::HardwareFaultEnum> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsActiveHardwareFaultsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralDiagnosticsActiveRadioFaultsAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterActiveRadioFaultsAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsActiveRadioFaultsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsActiveRadioFaultsAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsActiveRadioFaultsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsActiveRadioFaultsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::GeneralDiagnostics::RadioFaultEnum> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsActiveRadioFaultsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralDiagnosticsActiveNetworkFaultsAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterActiveNetworkFaultsAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsActiveNetworkFaultsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsActiveNetworkFaultsAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsActiveNetworkFaultsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsActiveNetworkFaultsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::GeneralDiagnostics::NetworkFaultEnum> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsActiveNetworkFaultsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralDiagnosticsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralDiagnosticsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralDiagnosticsEventListAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterEventListAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsEventListAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGeneralDiagnosticsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPGeneralDiagnosticsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPGeneralDiagnosticsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGeneralDiagnosticsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPGeneralDiagnosticsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGeneralDiagnosticsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGeneralDiagnosticsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPSoftwareDiagnosticsThreadMetricsAttributeCallback : public chip::Callback::Callback<CHIPSoftwareDiagnosticsClusterThreadMetricsAttributeCallbackType>
{
public:
    CHIPSoftwareDiagnosticsThreadMetricsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSoftwareDiagnosticsThreadMetricsAttributeCallback();

    static void maybeDestroy(CHIPSoftwareDiagnosticsThreadMetricsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSoftwareDiagnosticsThreadMetricsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::SoftwareDiagnostics::Structs::ThreadMetricsStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSoftwareDiagnosticsThreadMetricsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPSoftwareDiagnosticsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPSoftwareDiagnosticsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPSoftwareDiagnosticsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSoftwareDiagnosticsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPSoftwareDiagnosticsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSoftwareDiagnosticsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSoftwareDiagnosticsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPSoftwareDiagnosticsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPSoftwareDiagnosticsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPSoftwareDiagnosticsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSoftwareDiagnosticsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPSoftwareDiagnosticsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSoftwareDiagnosticsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSoftwareDiagnosticsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPSoftwareDiagnosticsEventListAttributeCallback : public chip::Callback::Callback<CHIPSoftwareDiagnosticsClusterEventListAttributeCallbackType>
{
public:
    CHIPSoftwareDiagnosticsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSoftwareDiagnosticsEventListAttributeCallback();

    static void maybeDestroy(CHIPSoftwareDiagnosticsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSoftwareDiagnosticsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSoftwareDiagnosticsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPSoftwareDiagnosticsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPSoftwareDiagnosticsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPSoftwareDiagnosticsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSoftwareDiagnosticsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPSoftwareDiagnosticsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSoftwareDiagnosticsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSoftwareDiagnosticsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPThreadNetworkDiagnosticsChannelAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterChannelAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsChannelAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsChannelAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsChannelAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsChannelAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsChannelAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsRoutingRoleAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterRoutingRoleAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsRoutingRoleAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsRoutingRoleAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsRoutingRoleAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsRoutingRoleAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::ThreadNetworkDiagnostics::RoutingRole> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsRoutingRoleAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsNetworkNameAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterNetworkNameAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsNetworkNameAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsNetworkNameAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsNetworkNameAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsNetworkNameAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::CharSpan> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsNetworkNameAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsPanIdAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterPanIdAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsPanIdAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsPanIdAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsPanIdAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsPanIdAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsPanIdAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsExtendedPanIdAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterExtendedPanIdAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsExtendedPanIdAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsExtendedPanIdAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsExtendedPanIdAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsExtendedPanIdAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsExtendedPanIdAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsMeshLocalPrefixAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterMeshLocalPrefixAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsMeshLocalPrefixAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsMeshLocalPrefixAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsMeshLocalPrefixAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsMeshLocalPrefixAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::ByteSpan> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsMeshLocalPrefixAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsNeighborTableAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterNeighborTableAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsNeighborTableAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsNeighborTableAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsNeighborTableAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsNeighborTableAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::ThreadNetworkDiagnostics::Structs::NeighborTable::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsNeighborTableAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsRouteTableAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterRouteTableAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsRouteTableAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsRouteTableAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsRouteTableAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsRouteTableAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::ThreadNetworkDiagnostics::Structs::RouteTable::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsRouteTableAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsPartitionIdAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterPartitionIdAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsPartitionIdAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsPartitionIdAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsPartitionIdAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsPartitionIdAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsPartitionIdAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsWeightingAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterWeightingAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsWeightingAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsWeightingAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsWeightingAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsWeightingAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsWeightingAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsDataVersionAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterDataVersionAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsDataVersionAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsDataVersionAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsDataVersionAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsDataVersionAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsDataVersionAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsStableDataVersionAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterStableDataVersionAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsStableDataVersionAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsStableDataVersionAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsStableDataVersionAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsStableDataVersionAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsStableDataVersionAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsLeaderRouterIdAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterLeaderRouterIdAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsLeaderRouterIdAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsLeaderRouterIdAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsLeaderRouterIdAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsLeaderRouterIdAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsLeaderRouterIdAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsActiveTimestampAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterActiveTimestampAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsActiveTimestampAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsActiveTimestampAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsActiveTimestampAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsActiveTimestampAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsActiveTimestampAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsPendingTimestampAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterPendingTimestampAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsPendingTimestampAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsPendingTimestampAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsPendingTimestampAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsPendingTimestampAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsPendingTimestampAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsDelayAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterDelayAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsDelayAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsDelayAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsDelayAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsDelayAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsDelayAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsSecurityPolicyAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterSecurityPolicyAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsSecurityPolicyAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsSecurityPolicyAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsSecurityPolicyAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsSecurityPolicyAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::ThreadNetworkDiagnostics::Structs::SecurityPolicy::DecodableType> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsSecurityPolicyAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsChannelPage0MaskAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterChannelPage0MaskAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsChannelPage0MaskAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsChannelPage0MaskAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsChannelPage0MaskAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsChannelPage0MaskAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::ByteSpan> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsChannelPage0MaskAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsOperationalDatasetComponentsAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterOperationalDatasetComponentsAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsOperationalDatasetComponentsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsOperationalDatasetComponentsAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsOperationalDatasetComponentsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsOperationalDatasetComponentsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::ThreadNetworkDiagnostics::Structs::OperationalDatasetComponents::DecodableType> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsOperationalDatasetComponentsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsActiveNetworkFaultsListAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterActiveNetworkFaultsListAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsActiveNetworkFaultsListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsActiveNetworkFaultsListAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsActiveNetworkFaultsListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsActiveNetworkFaultsListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::ThreadNetworkDiagnostics::NetworkFault> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsActiveNetworkFaultsListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsEventListAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterEventListAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsEventListAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThreadNetworkDiagnosticsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPThreadNetworkDiagnosticsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPThreadNetworkDiagnosticsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThreadNetworkDiagnosticsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPThreadNetworkDiagnosticsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThreadNetworkDiagnosticsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThreadNetworkDiagnosticsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPWiFiNetworkDiagnosticsBssidAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterBssidAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsBssidAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsBssidAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsBssidAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsBssidAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::ByteSpan> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsBssidAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsSecurityTypeAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterSecurityTypeAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsSecurityTypeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsSecurityTypeAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsSecurityTypeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsSecurityTypeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::WiFiNetworkDiagnostics::SecurityTypeEnum> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsSecurityTypeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsWiFiVersionAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterWiFiVersionAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsWiFiVersionAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsWiFiVersionAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsWiFiVersionAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsWiFiVersionAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::WiFiNetworkDiagnostics::WiFiVersionEnum> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsWiFiVersionAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsChannelNumberAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterChannelNumberAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsChannelNumberAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsChannelNumberAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsChannelNumberAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsChannelNumberAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsChannelNumberAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsRssiAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterRssiAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsRssiAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsRssiAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsRssiAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsRssiAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsRssiAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsBeaconLostCountAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterBeaconLostCountAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsBeaconLostCountAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsBeaconLostCountAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsBeaconLostCountAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsBeaconLostCountAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsBeaconLostCountAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsBeaconRxCountAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterBeaconRxCountAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsBeaconRxCountAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsBeaconRxCountAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsBeaconRxCountAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsBeaconRxCountAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsBeaconRxCountAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsPacketMulticastRxCountAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterPacketMulticastRxCountAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsPacketMulticastRxCountAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsPacketMulticastRxCountAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsPacketMulticastRxCountAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsPacketMulticastRxCountAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsPacketMulticastRxCountAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsPacketMulticastTxCountAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterPacketMulticastTxCountAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsPacketMulticastTxCountAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsPacketMulticastTxCountAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsPacketMulticastTxCountAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsPacketMulticastTxCountAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsPacketMulticastTxCountAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsPacketUnicastRxCountAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterPacketUnicastRxCountAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsPacketUnicastRxCountAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsPacketUnicastRxCountAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsPacketUnicastRxCountAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsPacketUnicastRxCountAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsPacketUnicastRxCountAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsPacketUnicastTxCountAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterPacketUnicastTxCountAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsPacketUnicastTxCountAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsPacketUnicastTxCountAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsPacketUnicastTxCountAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsPacketUnicastTxCountAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsPacketUnicastTxCountAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsCurrentMaxRateAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterCurrentMaxRateAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsCurrentMaxRateAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsCurrentMaxRateAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsCurrentMaxRateAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsCurrentMaxRateAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsCurrentMaxRateAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsOverrunCountAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterOverrunCountAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsOverrunCountAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsOverrunCountAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsOverrunCountAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsOverrunCountAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsOverrunCountAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsEventListAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterEventListAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsEventListAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWiFiNetworkDiagnosticsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPWiFiNetworkDiagnosticsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPWiFiNetworkDiagnosticsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWiFiNetworkDiagnosticsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPWiFiNetworkDiagnosticsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWiFiNetworkDiagnosticsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWiFiNetworkDiagnosticsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPEthernetNetworkDiagnosticsPHYRateAttributeCallback : public chip::Callback::Callback<CHIPEthernetNetworkDiagnosticsClusterPHYRateAttributeCallbackType>
{
public:
    CHIPEthernetNetworkDiagnosticsPHYRateAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPEthernetNetworkDiagnosticsPHYRateAttributeCallback();

    static void maybeDestroy(CHIPEthernetNetworkDiagnosticsPHYRateAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPEthernetNetworkDiagnosticsPHYRateAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::EthernetNetworkDiagnostics::PHYRateEnum> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPEthernetNetworkDiagnosticsPHYRateAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPEthernetNetworkDiagnosticsFullDuplexAttributeCallback : public chip::Callback::Callback<CHIPEthernetNetworkDiagnosticsClusterFullDuplexAttributeCallbackType>
{
public:
    CHIPEthernetNetworkDiagnosticsFullDuplexAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPEthernetNetworkDiagnosticsFullDuplexAttributeCallback();

    static void maybeDestroy(CHIPEthernetNetworkDiagnosticsFullDuplexAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPEthernetNetworkDiagnosticsFullDuplexAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<bool> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPEthernetNetworkDiagnosticsFullDuplexAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPEthernetNetworkDiagnosticsCarrierDetectAttributeCallback : public chip::Callback::Callback<CHIPEthernetNetworkDiagnosticsClusterCarrierDetectAttributeCallbackType>
{
public:
    CHIPEthernetNetworkDiagnosticsCarrierDetectAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPEthernetNetworkDiagnosticsCarrierDetectAttributeCallback();

    static void maybeDestroy(CHIPEthernetNetworkDiagnosticsCarrierDetectAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPEthernetNetworkDiagnosticsCarrierDetectAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<bool> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPEthernetNetworkDiagnosticsCarrierDetectAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPEthernetNetworkDiagnosticsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPEthernetNetworkDiagnosticsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPEthernetNetworkDiagnosticsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPEthernetNetworkDiagnosticsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPEthernetNetworkDiagnosticsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPEthernetNetworkDiagnosticsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPEthernetNetworkDiagnosticsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPEthernetNetworkDiagnosticsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPEthernetNetworkDiagnosticsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPEthernetNetworkDiagnosticsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPEthernetNetworkDiagnosticsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPEthernetNetworkDiagnosticsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPEthernetNetworkDiagnosticsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPEthernetNetworkDiagnosticsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPEthernetNetworkDiagnosticsEventListAttributeCallback : public chip::Callback::Callback<CHIPEthernetNetworkDiagnosticsClusterEventListAttributeCallbackType>
{
public:
    CHIPEthernetNetworkDiagnosticsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPEthernetNetworkDiagnosticsEventListAttributeCallback();

    static void maybeDestroy(CHIPEthernetNetworkDiagnosticsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPEthernetNetworkDiagnosticsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPEthernetNetworkDiagnosticsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPEthernetNetworkDiagnosticsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPEthernetNetworkDiagnosticsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPEthernetNetworkDiagnosticsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPEthernetNetworkDiagnosticsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPEthernetNetworkDiagnosticsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPEthernetNetworkDiagnosticsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPEthernetNetworkDiagnosticsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPBridgedDeviceBasicInformationVendorIDAttributeCallback : public chip::Callback::Callback<CHIPBridgedDeviceBasicInformationClusterVendorIDAttributeCallbackType>
{
public:
    CHIPBridgedDeviceBasicInformationVendorIDAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBridgedDeviceBasicInformationVendorIDAttributeCallback();

    static void maybeDestroy(CHIPBridgedDeviceBasicInformationVendorIDAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBridgedDeviceBasicInformationVendorIDAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::VendorId value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBridgedDeviceBasicInformationVendorIDAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBridgedDeviceBasicInformationProductAppearanceAttributeCallback : public chip::Callback::Callback<CHIPBridgedDeviceBasicInformationClusterProductAppearanceAttributeCallbackType>
{
public:
    CHIPBridgedDeviceBasicInformationProductAppearanceAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBridgedDeviceBasicInformationProductAppearanceAttributeCallback();

    static void maybeDestroy(CHIPBridgedDeviceBasicInformationProductAppearanceAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBridgedDeviceBasicInformationProductAppearanceAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::BridgedDeviceBasicInformation::Structs::ProductAppearanceStruct::DecodableType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBridgedDeviceBasicInformationProductAppearanceAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBridgedDeviceBasicInformationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBridgedDeviceBasicInformationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPBridgedDeviceBasicInformationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBridgedDeviceBasicInformationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBridgedDeviceBasicInformationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBridgedDeviceBasicInformationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBridgedDeviceBasicInformationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBridgedDeviceBasicInformationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBridgedDeviceBasicInformationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPBridgedDeviceBasicInformationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBridgedDeviceBasicInformationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBridgedDeviceBasicInformationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBridgedDeviceBasicInformationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBridgedDeviceBasicInformationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBridgedDeviceBasicInformationEventListAttributeCallback : public chip::Callback::Callback<CHIPBridgedDeviceBasicInformationClusterEventListAttributeCallbackType>
{
public:
    CHIPBridgedDeviceBasicInformationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBridgedDeviceBasicInformationEventListAttributeCallback();

    static void maybeDestroy(CHIPBridgedDeviceBasicInformationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBridgedDeviceBasicInformationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBridgedDeviceBasicInformationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBridgedDeviceBasicInformationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPBridgedDeviceBasicInformationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPBridgedDeviceBasicInformationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBridgedDeviceBasicInformationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPBridgedDeviceBasicInformationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBridgedDeviceBasicInformationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBridgedDeviceBasicInformationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPSwitchGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPSwitchClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPSwitchGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSwitchGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPSwitchGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSwitchGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSwitchGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPSwitchAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPSwitchClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPSwitchAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSwitchAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPSwitchAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSwitchAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSwitchAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPSwitchEventListAttributeCallback : public chip::Callback::Callback<CHIPSwitchClusterEventListAttributeCallbackType>
{
public:
    CHIPSwitchEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSwitchEventListAttributeCallback();

    static void maybeDestroy(CHIPSwitchEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSwitchEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSwitchEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPSwitchAttributeListAttributeCallback : public chip::Callback::Callback<CHIPSwitchClusterAttributeListAttributeCallbackType>
{
public:
    CHIPSwitchAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPSwitchAttributeListAttributeCallback();

    static void maybeDestroy(CHIPSwitchAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPSwitchAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPSwitchAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPAdministratorCommissioningWindowStatusAttributeCallback : public chip::Callback::Callback<CHIPAdministratorCommissioningClusterWindowStatusAttributeCallbackType>
{
public:
    CHIPAdministratorCommissioningWindowStatusAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAdministratorCommissioningWindowStatusAttributeCallback();

    static void maybeDestroy(CHIPAdministratorCommissioningWindowStatusAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAdministratorCommissioningWindowStatusAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::AdministratorCommissioning::CommissioningWindowStatusEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAdministratorCommissioningWindowStatusAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAdministratorCommissioningAdminFabricIndexAttributeCallback : public chip::Callback::Callback<CHIPAdministratorCommissioningClusterAdminFabricIndexAttributeCallbackType>
{
public:
    CHIPAdministratorCommissioningAdminFabricIndexAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAdministratorCommissioningAdminFabricIndexAttributeCallback();

    static void maybeDestroy(CHIPAdministratorCommissioningAdminFabricIndexAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAdministratorCommissioningAdminFabricIndexAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::FabricIndex> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAdministratorCommissioningAdminFabricIndexAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAdministratorCommissioningAdminVendorIdAttributeCallback : public chip::Callback::Callback<CHIPAdministratorCommissioningClusterAdminVendorIdAttributeCallbackType>
{
public:
    CHIPAdministratorCommissioningAdminVendorIdAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAdministratorCommissioningAdminVendorIdAttributeCallback();

    static void maybeDestroy(CHIPAdministratorCommissioningAdminVendorIdAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAdministratorCommissioningAdminVendorIdAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAdministratorCommissioningAdminVendorIdAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAdministratorCommissioningGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPAdministratorCommissioningClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPAdministratorCommissioningGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAdministratorCommissioningGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPAdministratorCommissioningGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAdministratorCommissioningGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAdministratorCommissioningGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAdministratorCommissioningAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPAdministratorCommissioningClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPAdministratorCommissioningAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAdministratorCommissioningAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPAdministratorCommissioningAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAdministratorCommissioningAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAdministratorCommissioningAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAdministratorCommissioningEventListAttributeCallback : public chip::Callback::Callback<CHIPAdministratorCommissioningClusterEventListAttributeCallbackType>
{
public:
    CHIPAdministratorCommissioningEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAdministratorCommissioningEventListAttributeCallback();

    static void maybeDestroy(CHIPAdministratorCommissioningEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAdministratorCommissioningEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAdministratorCommissioningEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAdministratorCommissioningAttributeListAttributeCallback : public chip::Callback::Callback<CHIPAdministratorCommissioningClusterAttributeListAttributeCallbackType>
{
public:
    CHIPAdministratorCommissioningAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAdministratorCommissioningAttributeListAttributeCallback();

    static void maybeDestroy(CHIPAdministratorCommissioningAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAdministratorCommissioningAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAdministratorCommissioningAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPOperationalCredentialsNOCsAttributeCallback : public chip::Callback::Callback<CHIPOperationalCredentialsClusterNOCsAttributeCallbackType>
{
public:
    CHIPOperationalCredentialsNOCsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOperationalCredentialsNOCsAttributeCallback();

    static void maybeDestroy(CHIPOperationalCredentialsNOCsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOperationalCredentialsNOCsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::OperationalCredentials::Structs::NOCStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOperationalCredentialsNOCsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOperationalCredentialsFabricsAttributeCallback : public chip::Callback::Callback<CHIPOperationalCredentialsClusterFabricsAttributeCallbackType>
{
public:
    CHIPOperationalCredentialsFabricsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOperationalCredentialsFabricsAttributeCallback();

    static void maybeDestroy(CHIPOperationalCredentialsFabricsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOperationalCredentialsFabricsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::OperationalCredentials::Structs::FabricDescriptorStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOperationalCredentialsFabricsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOperationalCredentialsTrustedRootCertificatesAttributeCallback : public chip::Callback::Callback<CHIPOperationalCredentialsClusterTrustedRootCertificatesAttributeCallbackType>
{
public:
    CHIPOperationalCredentialsTrustedRootCertificatesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOperationalCredentialsTrustedRootCertificatesAttributeCallback();

    static void maybeDestroy(CHIPOperationalCredentialsTrustedRootCertificatesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOperationalCredentialsTrustedRootCertificatesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::ByteSpan> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOperationalCredentialsTrustedRootCertificatesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOperationalCredentialsGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOperationalCredentialsClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPOperationalCredentialsGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOperationalCredentialsGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOperationalCredentialsGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOperationalCredentialsGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOperationalCredentialsGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOperationalCredentialsAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOperationalCredentialsClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPOperationalCredentialsAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOperationalCredentialsAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOperationalCredentialsAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOperationalCredentialsAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOperationalCredentialsAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOperationalCredentialsEventListAttributeCallback : public chip::Callback::Callback<CHIPOperationalCredentialsClusterEventListAttributeCallbackType>
{
public:
    CHIPOperationalCredentialsEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOperationalCredentialsEventListAttributeCallback();

    static void maybeDestroy(CHIPOperationalCredentialsEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOperationalCredentialsEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOperationalCredentialsEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOperationalCredentialsAttributeListAttributeCallback : public chip::Callback::Callback<CHIPOperationalCredentialsClusterAttributeListAttributeCallbackType>
{
public:
    CHIPOperationalCredentialsAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOperationalCredentialsAttributeListAttributeCallback();

    static void maybeDestroy(CHIPOperationalCredentialsAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOperationalCredentialsAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOperationalCredentialsAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPGroupKeyManagementGroupKeyMapAttributeCallback : public chip::Callback::Callback<CHIPGroupKeyManagementClusterGroupKeyMapAttributeCallbackType>
{
public:
    CHIPGroupKeyManagementGroupKeyMapAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupKeyManagementGroupKeyMapAttributeCallback();

    static void maybeDestroy(CHIPGroupKeyManagementGroupKeyMapAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupKeyManagementGroupKeyMapAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::GroupKeyManagement::Structs::GroupKeyMapStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupKeyManagementGroupKeyMapAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGroupKeyManagementGroupTableAttributeCallback : public chip::Callback::Callback<CHIPGroupKeyManagementClusterGroupTableAttributeCallbackType>
{
public:
    CHIPGroupKeyManagementGroupTableAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupKeyManagementGroupTableAttributeCallback();

    static void maybeDestroy(CHIPGroupKeyManagementGroupTableAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupKeyManagementGroupTableAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::GroupKeyManagement::Structs::GroupInfoMapStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupKeyManagementGroupTableAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGroupKeyManagementGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPGroupKeyManagementClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPGroupKeyManagementGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupKeyManagementGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPGroupKeyManagementGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupKeyManagementGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupKeyManagementGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGroupKeyManagementAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPGroupKeyManagementClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPGroupKeyManagementAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupKeyManagementAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPGroupKeyManagementAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupKeyManagementAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupKeyManagementAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGroupKeyManagementEventListAttributeCallback : public chip::Callback::Callback<CHIPGroupKeyManagementClusterEventListAttributeCallbackType>
{
public:
    CHIPGroupKeyManagementEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupKeyManagementEventListAttributeCallback();

    static void maybeDestroy(CHIPGroupKeyManagementEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupKeyManagementEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupKeyManagementEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPGroupKeyManagementAttributeListAttributeCallback : public chip::Callback::Callback<CHIPGroupKeyManagementClusterAttributeListAttributeCallbackType>
{
public:
    CHIPGroupKeyManagementAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPGroupKeyManagementAttributeListAttributeCallback();

    static void maybeDestroy(CHIPGroupKeyManagementAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPGroupKeyManagementAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPGroupKeyManagementAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPFixedLabelLabelListAttributeCallback : public chip::Callback::Callback<CHIPFixedLabelClusterLabelListAttributeCallbackType>
{
public:
    CHIPFixedLabelLabelListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFixedLabelLabelListAttributeCallback();

    static void maybeDestroy(CHIPFixedLabelLabelListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFixedLabelLabelListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::FixedLabel::Structs::LabelStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFixedLabelLabelListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFixedLabelGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPFixedLabelClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPFixedLabelGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFixedLabelGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPFixedLabelGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFixedLabelGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFixedLabelGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFixedLabelAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPFixedLabelClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPFixedLabelAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFixedLabelAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPFixedLabelAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFixedLabelAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFixedLabelAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFixedLabelEventListAttributeCallback : public chip::Callback::Callback<CHIPFixedLabelClusterEventListAttributeCallbackType>
{
public:
    CHIPFixedLabelEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFixedLabelEventListAttributeCallback();

    static void maybeDestroy(CHIPFixedLabelEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFixedLabelEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFixedLabelEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFixedLabelAttributeListAttributeCallback : public chip::Callback::Callback<CHIPFixedLabelClusterAttributeListAttributeCallbackType>
{
public:
    CHIPFixedLabelAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFixedLabelAttributeListAttributeCallback();

    static void maybeDestroy(CHIPFixedLabelAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFixedLabelAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFixedLabelAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPUserLabelLabelListAttributeCallback : public chip::Callback::Callback<CHIPUserLabelClusterLabelListAttributeCallbackType>
{
public:
    CHIPUserLabelLabelListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUserLabelLabelListAttributeCallback();

    static void maybeDestroy(CHIPUserLabelLabelListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUserLabelLabelListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::UserLabel::Structs::LabelStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUserLabelLabelListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUserLabelGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPUserLabelClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPUserLabelGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUserLabelGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPUserLabelGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUserLabelGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUserLabelGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUserLabelAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPUserLabelClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPUserLabelAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUserLabelAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPUserLabelAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUserLabelAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUserLabelAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUserLabelEventListAttributeCallback : public chip::Callback::Callback<CHIPUserLabelClusterEventListAttributeCallbackType>
{
public:
    CHIPUserLabelEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUserLabelEventListAttributeCallback();

    static void maybeDestroy(CHIPUserLabelEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUserLabelEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUserLabelEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUserLabelAttributeListAttributeCallback : public chip::Callback::Callback<CHIPUserLabelClusterAttributeListAttributeCallbackType>
{
public:
    CHIPUserLabelAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUserLabelAttributeListAttributeCallback();

    static void maybeDestroy(CHIPUserLabelAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUserLabelAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUserLabelAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPBooleanStateGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBooleanStateClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPBooleanStateGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBooleanStateGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBooleanStateGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBooleanStateGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBooleanStateGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBooleanStateAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBooleanStateClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPBooleanStateAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBooleanStateAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBooleanStateAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBooleanStateAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBooleanStateAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBooleanStateEventListAttributeCallback : public chip::Callback::Callback<CHIPBooleanStateClusterEventListAttributeCallbackType>
{
public:
    CHIPBooleanStateEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBooleanStateEventListAttributeCallback();

    static void maybeDestroy(CHIPBooleanStateEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBooleanStateEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBooleanStateEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBooleanStateAttributeListAttributeCallback : public chip::Callback::Callback<CHIPBooleanStateClusterAttributeListAttributeCallbackType>
{
public:
    CHIPBooleanStateAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBooleanStateAttributeListAttributeCallback();

    static void maybeDestroy(CHIPBooleanStateAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBooleanStateAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBooleanStateAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPModeSelectStandardNamespaceAttributeCallback : public chip::Callback::Callback<CHIPModeSelectClusterStandardNamespaceAttributeCallbackType>
{
public:
    CHIPModeSelectStandardNamespaceAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPModeSelectStandardNamespaceAttributeCallback();

    static void maybeDestroy(CHIPModeSelectStandardNamespaceAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPModeSelectStandardNamespaceAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPModeSelectStandardNamespaceAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPModeSelectSupportedModesAttributeCallback : public chip::Callback::Callback<CHIPModeSelectClusterSupportedModesAttributeCallbackType>
{
public:
    CHIPModeSelectSupportedModesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPModeSelectSupportedModesAttributeCallback();

    static void maybeDestroy(CHIPModeSelectSupportedModesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPModeSelectSupportedModesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::ModeSelect::Structs::ModeOptionStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPModeSelectSupportedModesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPModeSelectStartUpModeAttributeCallback : public chip::Callback::Callback<CHIPModeSelectClusterStartUpModeAttributeCallbackType>
{
public:
    CHIPModeSelectStartUpModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPModeSelectStartUpModeAttributeCallback();

    static void maybeDestroy(CHIPModeSelectStartUpModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPModeSelectStartUpModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPModeSelectStartUpModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPModeSelectOnModeAttributeCallback : public chip::Callback::Callback<CHIPModeSelectClusterOnModeAttributeCallbackType>
{
public:
    CHIPModeSelectOnModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPModeSelectOnModeAttributeCallback();

    static void maybeDestroy(CHIPModeSelectOnModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPModeSelectOnModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPModeSelectOnModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPModeSelectGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPModeSelectClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPModeSelectGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPModeSelectGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPModeSelectGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPModeSelectGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPModeSelectGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPModeSelectAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPModeSelectClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPModeSelectAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPModeSelectAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPModeSelectAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPModeSelectAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPModeSelectAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPModeSelectEventListAttributeCallback : public chip::Callback::Callback<CHIPModeSelectClusterEventListAttributeCallbackType>
{
public:
    CHIPModeSelectEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPModeSelectEventListAttributeCallback();

    static void maybeDestroy(CHIPModeSelectEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPModeSelectEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPModeSelectEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPModeSelectAttributeListAttributeCallback : public chip::Callback::Callback<CHIPModeSelectClusterAttributeListAttributeCallbackType>
{
public:
    CHIPModeSelectAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPModeSelectAttributeListAttributeCallback();

    static void maybeDestroy(CHIPModeSelectAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPModeSelectAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPModeSelectAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPDoorLockLockStateAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterLockStateAttributeCallbackType>
{
public:
    CHIPDoorLockLockStateAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockLockStateAttributeCallback();

    static void maybeDestroy(CHIPDoorLockLockStateAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockLockStateAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::DoorLock::DlLockState> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockLockStateAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockLockTypeAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterLockTypeAttributeCallbackType>
{
public:
    CHIPDoorLockLockTypeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockLockTypeAttributeCallback();

    static void maybeDestroy(CHIPDoorLockLockTypeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockLockTypeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::DoorLock::DlLockType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockLockTypeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockDoorStateAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterDoorStateAttributeCallbackType>
{
public:
    CHIPDoorLockDoorStateAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockDoorStateAttributeCallback();

    static void maybeDestroy(CHIPDoorLockDoorStateAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockDoorStateAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::DoorLock::DoorStateEnum> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockDoorStateAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockCredentialRulesSupportAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterCredentialRulesSupportAttributeCallbackType>
{
public:
    CHIPDoorLockCredentialRulesSupportAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockCredentialRulesSupportAttributeCallback();

    static void maybeDestroy(CHIPDoorLockCredentialRulesSupportAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockCredentialRulesSupportAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::DoorLock::DlCredentialRuleMask> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockCredentialRulesSupportAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockOperatingModeAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterOperatingModeAttributeCallbackType>
{
public:
    CHIPDoorLockOperatingModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockOperatingModeAttributeCallback();

    static void maybeDestroy(CHIPDoorLockOperatingModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockOperatingModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::DoorLock::OperatingModeEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockOperatingModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockSupportedOperatingModesAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterSupportedOperatingModesAttributeCallbackType>
{
public:
    CHIPDoorLockSupportedOperatingModesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockSupportedOperatingModesAttributeCallback();

    static void maybeDestroy(CHIPDoorLockSupportedOperatingModesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockSupportedOperatingModesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::DoorLock::DlSupportedOperatingModes> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockSupportedOperatingModesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockDefaultConfigurationRegisterAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterDefaultConfigurationRegisterAttributeCallbackType>
{
public:
    CHIPDoorLockDefaultConfigurationRegisterAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockDefaultConfigurationRegisterAttributeCallback();

    static void maybeDestroy(CHIPDoorLockDefaultConfigurationRegisterAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockDefaultConfigurationRegisterAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::DoorLock::DlDefaultConfigurationRegister> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockDefaultConfigurationRegisterAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockLocalProgrammingFeaturesAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterLocalProgrammingFeaturesAttributeCallbackType>
{
public:
    CHIPDoorLockLocalProgrammingFeaturesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockLocalProgrammingFeaturesAttributeCallback();

    static void maybeDestroy(CHIPDoorLockLocalProgrammingFeaturesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockLocalProgrammingFeaturesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::DoorLock::DlLocalProgrammingFeatures> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockLocalProgrammingFeaturesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPDoorLockGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPDoorLockGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPDoorLockAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPDoorLockAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockEventListAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterEventListAttributeCallbackType>
{
public:
    CHIPDoorLockEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockEventListAttributeCallback();

    static void maybeDestroy(CHIPDoorLockEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPDoorLockAttributeListAttributeCallback : public chip::Callback::Callback<CHIPDoorLockClusterAttributeListAttributeCallbackType>
{
public:
    CHIPDoorLockAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPDoorLockAttributeListAttributeCallback();

    static void maybeDestroy(CHIPDoorLockAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPDoorLockAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPDoorLockAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPWindowCoveringTypeAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterTypeAttributeCallbackType>
{
public:
    CHIPWindowCoveringTypeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringTypeAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringTypeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringTypeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::WindowCovering::Type value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringTypeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringCurrentPositionLiftAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterCurrentPositionLiftAttributeCallbackType>
{
public:
    CHIPWindowCoveringCurrentPositionLiftAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringCurrentPositionLiftAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringCurrentPositionLiftAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringCurrentPositionLiftAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringCurrentPositionLiftAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringCurrentPositionTiltAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterCurrentPositionTiltAttributeCallbackType>
{
public:
    CHIPWindowCoveringCurrentPositionTiltAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringCurrentPositionTiltAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringCurrentPositionTiltAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringCurrentPositionTiltAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringCurrentPositionTiltAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringConfigStatusAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterConfigStatusAttributeCallbackType>
{
public:
    CHIPWindowCoveringConfigStatusAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringConfigStatusAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringConfigStatusAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringConfigStatusAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::WindowCovering::ConfigStatus> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringConfigStatusAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringCurrentPositionLiftPercentageAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterCurrentPositionLiftPercentageAttributeCallbackType>
{
public:
    CHIPWindowCoveringCurrentPositionLiftPercentageAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringCurrentPositionLiftPercentageAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringCurrentPositionLiftPercentageAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringCurrentPositionLiftPercentageAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::Percent> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringCurrentPositionLiftPercentageAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringCurrentPositionTiltPercentageAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterCurrentPositionTiltPercentageAttributeCallbackType>
{
public:
    CHIPWindowCoveringCurrentPositionTiltPercentageAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringCurrentPositionTiltPercentageAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringCurrentPositionTiltPercentageAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringCurrentPositionTiltPercentageAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::Percent> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringCurrentPositionTiltPercentageAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringOperationalStatusAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterOperationalStatusAttributeCallbackType>
{
public:
    CHIPWindowCoveringOperationalStatusAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringOperationalStatusAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringOperationalStatusAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringOperationalStatusAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::WindowCovering::OperationalStatus> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringOperationalStatusAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringTargetPositionLiftPercent100thsAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterTargetPositionLiftPercent100thsAttributeCallbackType>
{
public:
    CHIPWindowCoveringTargetPositionLiftPercent100thsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringTargetPositionLiftPercent100thsAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringTargetPositionLiftPercent100thsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringTargetPositionLiftPercent100thsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::Percent100ths> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringTargetPositionLiftPercent100thsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringTargetPositionTiltPercent100thsAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterTargetPositionTiltPercent100thsAttributeCallbackType>
{
public:
    CHIPWindowCoveringTargetPositionTiltPercent100thsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringTargetPositionTiltPercent100thsAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringTargetPositionTiltPercent100thsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringTargetPositionTiltPercent100thsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::Percent100ths> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringTargetPositionTiltPercent100thsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringEndProductTypeAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterEndProductTypeAttributeCallbackType>
{
public:
    CHIPWindowCoveringEndProductTypeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringEndProductTypeAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringEndProductTypeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringEndProductTypeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::WindowCovering::EndProductType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringEndProductTypeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringCurrentPositionLiftPercent100thsAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterCurrentPositionLiftPercent100thsAttributeCallbackType>
{
public:
    CHIPWindowCoveringCurrentPositionLiftPercent100thsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringCurrentPositionLiftPercent100thsAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringCurrentPositionLiftPercent100thsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringCurrentPositionLiftPercent100thsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::Percent100ths> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringCurrentPositionLiftPercent100thsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringCurrentPositionTiltPercent100thsAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterCurrentPositionTiltPercent100thsAttributeCallbackType>
{
public:
    CHIPWindowCoveringCurrentPositionTiltPercent100thsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringCurrentPositionTiltPercent100thsAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringCurrentPositionTiltPercent100thsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringCurrentPositionTiltPercent100thsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::Percent100ths> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringCurrentPositionTiltPercent100thsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringModeAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterModeAttributeCallbackType>
{
public:
    CHIPWindowCoveringModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringModeAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::WindowCovering::Mode> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringSafetyStatusAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterSafetyStatusAttributeCallbackType>
{
public:
    CHIPWindowCoveringSafetyStatusAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringSafetyStatusAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringSafetyStatusAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringSafetyStatusAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::WindowCovering::SafetyStatus> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringSafetyStatusAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPWindowCoveringGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPWindowCoveringAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringEventListAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterEventListAttributeCallbackType>
{
public:
    CHIPWindowCoveringEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringEventListAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWindowCoveringAttributeListAttributeCallback : public chip::Callback::Callback<CHIPWindowCoveringClusterAttributeListAttributeCallbackType>
{
public:
    CHIPWindowCoveringAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWindowCoveringAttributeListAttributeCallback();

    static void maybeDestroy(CHIPWindowCoveringAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWindowCoveringAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWindowCoveringAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPBarrierControlGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBarrierControlClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPBarrierControlGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBarrierControlGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBarrierControlGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBarrierControlGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBarrierControlGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBarrierControlAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBarrierControlClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPBarrierControlAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBarrierControlAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBarrierControlAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBarrierControlAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBarrierControlAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBarrierControlEventListAttributeCallback : public chip::Callback::Callback<CHIPBarrierControlClusterEventListAttributeCallbackType>
{
public:
    CHIPBarrierControlEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBarrierControlEventListAttributeCallback();

    static void maybeDestroy(CHIPBarrierControlEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBarrierControlEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBarrierControlEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBarrierControlAttributeListAttributeCallback : public chip::Callback::Callback<CHIPBarrierControlClusterAttributeListAttributeCallbackType>
{
public:
    CHIPBarrierControlAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBarrierControlAttributeListAttributeCallback();

    static void maybeDestroy(CHIPBarrierControlAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBarrierControlAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBarrierControlAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPPumpConfigurationAndControlMaxPressureAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMaxPressureAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMaxPressureAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMaxPressureAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMaxPressureAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMaxPressureAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMaxPressureAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMaxSpeedAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMaxSpeedAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMaxSpeedAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMaxSpeedAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMaxSpeedAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMaxSpeedAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMaxSpeedAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMaxFlowAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMaxFlowAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMaxFlowAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMaxFlowAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMaxFlowAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMaxFlowAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMaxFlowAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMinConstPressureAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMinConstPressureAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMinConstPressureAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMinConstPressureAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMinConstPressureAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMinConstPressureAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMinConstPressureAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMaxConstPressureAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMaxConstPressureAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMaxConstPressureAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMaxConstPressureAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMaxConstPressureAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMaxConstPressureAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMaxConstPressureAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMinCompPressureAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMinCompPressureAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMinCompPressureAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMinCompPressureAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMinCompPressureAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMinCompPressureAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMinCompPressureAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMaxCompPressureAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMaxCompPressureAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMaxCompPressureAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMaxCompPressureAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMaxCompPressureAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMaxCompPressureAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMaxCompPressureAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMinConstSpeedAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMinConstSpeedAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMinConstSpeedAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMinConstSpeedAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMinConstSpeedAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMinConstSpeedAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMinConstSpeedAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMaxConstSpeedAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMaxConstSpeedAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMaxConstSpeedAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMaxConstSpeedAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMaxConstSpeedAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMaxConstSpeedAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMaxConstSpeedAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMinConstFlowAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMinConstFlowAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMinConstFlowAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMinConstFlowAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMinConstFlowAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMinConstFlowAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMinConstFlowAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMaxConstFlowAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMaxConstFlowAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMaxConstFlowAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMaxConstFlowAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMaxConstFlowAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMaxConstFlowAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMaxConstFlowAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMinConstTempAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMinConstTempAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMinConstTempAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMinConstTempAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMinConstTempAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMinConstTempAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMinConstTempAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlMaxConstTempAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterMaxConstTempAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlMaxConstTempAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlMaxConstTempAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlMaxConstTempAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlMaxConstTempAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlMaxConstTempAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlPumpStatusAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterPumpStatusAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlPumpStatusAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlPumpStatusAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlPumpStatusAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlPumpStatusAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::PumpConfigurationAndControl::PumpStatusBitmap> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlPumpStatusAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlEffectiveOperationModeAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterEffectiveOperationModeAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlEffectiveOperationModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlEffectiveOperationModeAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlEffectiveOperationModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlEffectiveOperationModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PumpConfigurationAndControl::OperationModeEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlEffectiveOperationModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlEffectiveControlModeAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterEffectiveControlModeAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlEffectiveControlModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlEffectiveControlModeAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlEffectiveControlModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlEffectiveControlModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PumpConfigurationAndControl::ControlModeEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlEffectiveControlModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlCapacityAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterCapacityAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlCapacityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlCapacityAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlCapacityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlCapacityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlCapacityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlSpeedAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterSpeedAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlSpeedAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlSpeedAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlSpeedAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlSpeedAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlSpeedAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlLifetimeRunningHoursAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterLifetimeRunningHoursAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlLifetimeRunningHoursAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlLifetimeRunningHoursAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlLifetimeRunningHoursAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlLifetimeRunningHoursAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlLifetimeRunningHoursAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlPowerAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterPowerAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlPowerAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlPowerAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlPowerAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlPowerAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlPowerAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlLifetimeEnergyConsumedAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterLifetimeEnergyConsumedAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlLifetimeEnergyConsumedAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlLifetimeEnergyConsumedAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlLifetimeEnergyConsumedAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlLifetimeEnergyConsumedAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlLifetimeEnergyConsumedAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlOperationModeAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterOperationModeAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlOperationModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlOperationModeAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlOperationModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlOperationModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PumpConfigurationAndControl::OperationModeEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlOperationModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlControlModeAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterControlModeAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlControlModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlControlModeAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlControlModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlControlModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::PumpConfigurationAndControl::ControlModeEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlControlModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlEventListAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterEventListAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlEventListAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPumpConfigurationAndControlAttributeListAttributeCallback : public chip::Callback::Callback<CHIPPumpConfigurationAndControlClusterAttributeListAttributeCallbackType>
{
public:
    CHIPPumpConfigurationAndControlAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPumpConfigurationAndControlAttributeListAttributeCallback();

    static void maybeDestroy(CHIPPumpConfigurationAndControlAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPumpConfigurationAndControlAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPumpConfigurationAndControlAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPThermostatLocalTemperatureAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterLocalTemperatureAttributeCallbackType>
{
public:
    CHIPThermostatLocalTemperatureAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatLocalTemperatureAttributeCallback();

    static void maybeDestroy(CHIPThermostatLocalTemperatureAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatLocalTemperatureAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatLocalTemperatureAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatOutdoorTemperatureAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterOutdoorTemperatureAttributeCallbackType>
{
public:
    CHIPThermostatOutdoorTemperatureAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatOutdoorTemperatureAttributeCallback();

    static void maybeDestroy(CHIPThermostatOutdoorTemperatureAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatOutdoorTemperatureAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatOutdoorTemperatureAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatControlSequenceOfOperationAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterControlSequenceOfOperationAttributeCallbackType>
{
public:
    CHIPThermostatControlSequenceOfOperationAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatControlSequenceOfOperationAttributeCallback();

    static void maybeDestroy(CHIPThermostatControlSequenceOfOperationAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatControlSequenceOfOperationAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::Thermostat::ThermostatControlSequence value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatControlSequenceOfOperationAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatTemperatureSetpointHoldDurationAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterTemperatureSetpointHoldDurationAttributeCallbackType>
{
public:
    CHIPThermostatTemperatureSetpointHoldDurationAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatTemperatureSetpointHoldDurationAttributeCallback();

    static void maybeDestroy(CHIPThermostatTemperatureSetpointHoldDurationAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatTemperatureSetpointHoldDurationAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatTemperatureSetpointHoldDurationAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatSetpointChangeAmountAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterSetpointChangeAmountAttributeCallbackType>
{
public:
    CHIPThermostatSetpointChangeAmountAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatSetpointChangeAmountAttributeCallback();

    static void maybeDestroy(CHIPThermostatSetpointChangeAmountAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatSetpointChangeAmountAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatSetpointChangeAmountAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatSetpointChangeSourceTimestampAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterSetpointChangeSourceTimestampAttributeCallbackType>
{
public:
    CHIPThermostatSetpointChangeSourceTimestampAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatSetpointChangeSourceTimestampAttributeCallback();

    static void maybeDestroy(CHIPThermostatSetpointChangeSourceTimestampAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatSetpointChangeSourceTimestampAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, uint32_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatSetpointChangeSourceTimestampAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatOccupiedSetbackAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterOccupiedSetbackAttributeCallbackType>
{
public:
    CHIPThermostatOccupiedSetbackAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatOccupiedSetbackAttributeCallback();

    static void maybeDestroy(CHIPThermostatOccupiedSetbackAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatOccupiedSetbackAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatOccupiedSetbackAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatOccupiedSetbackMinAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterOccupiedSetbackMinAttributeCallbackType>
{
public:
    CHIPThermostatOccupiedSetbackMinAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatOccupiedSetbackMinAttributeCallback();

    static void maybeDestroy(CHIPThermostatOccupiedSetbackMinAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatOccupiedSetbackMinAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatOccupiedSetbackMinAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatOccupiedSetbackMaxAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterOccupiedSetbackMaxAttributeCallbackType>
{
public:
    CHIPThermostatOccupiedSetbackMaxAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatOccupiedSetbackMaxAttributeCallback();

    static void maybeDestroy(CHIPThermostatOccupiedSetbackMaxAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatOccupiedSetbackMaxAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatOccupiedSetbackMaxAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatUnoccupiedSetbackAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterUnoccupiedSetbackAttributeCallbackType>
{
public:
    CHIPThermostatUnoccupiedSetbackAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatUnoccupiedSetbackAttributeCallback();

    static void maybeDestroy(CHIPThermostatUnoccupiedSetbackAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatUnoccupiedSetbackAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatUnoccupiedSetbackAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatUnoccupiedSetbackMinAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterUnoccupiedSetbackMinAttributeCallbackType>
{
public:
    CHIPThermostatUnoccupiedSetbackMinAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatUnoccupiedSetbackMinAttributeCallback();

    static void maybeDestroy(CHIPThermostatUnoccupiedSetbackMinAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatUnoccupiedSetbackMinAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatUnoccupiedSetbackMinAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatUnoccupiedSetbackMaxAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterUnoccupiedSetbackMaxAttributeCallbackType>
{
public:
    CHIPThermostatUnoccupiedSetbackMaxAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatUnoccupiedSetbackMaxAttributeCallback();

    static void maybeDestroy(CHIPThermostatUnoccupiedSetbackMaxAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatUnoccupiedSetbackMaxAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatUnoccupiedSetbackMaxAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatACCoilTemperatureAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterACCoilTemperatureAttributeCallbackType>
{
public:
    CHIPThermostatACCoilTemperatureAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatACCoilTemperatureAttributeCallback();

    static void maybeDestroy(CHIPThermostatACCoilTemperatureAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatACCoilTemperatureAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatACCoilTemperatureAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPThermostatGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPThermostatGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPThermostatAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPThermostatAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatEventListAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterEventListAttributeCallbackType>
{
public:
    CHIPThermostatEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatEventListAttributeCallback();

    static void maybeDestroy(CHIPThermostatEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatAttributeListAttributeCallback : public chip::Callback::Callback<CHIPThermostatClusterAttributeListAttributeCallbackType>
{
public:
    CHIPThermostatAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatAttributeListAttributeCallback();

    static void maybeDestroy(CHIPThermostatAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPFanControlFanModeAttributeCallback : public chip::Callback::Callback<CHIPFanControlClusterFanModeAttributeCallbackType>
{
public:
    CHIPFanControlFanModeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFanControlFanModeAttributeCallback();

    static void maybeDestroy(CHIPFanControlFanModeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFanControlFanModeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::FanControl::FanModeType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFanControlFanModeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFanControlFanModeSequenceAttributeCallback : public chip::Callback::Callback<CHIPFanControlClusterFanModeSequenceAttributeCallbackType>
{
public:
    CHIPFanControlFanModeSequenceAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFanControlFanModeSequenceAttributeCallback();

    static void maybeDestroy(CHIPFanControlFanModeSequenceAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFanControlFanModeSequenceAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::FanControl::FanModeSequenceType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFanControlFanModeSequenceAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFanControlPercentSettingAttributeCallback : public chip::Callback::Callback<CHIPFanControlClusterPercentSettingAttributeCallbackType>
{
public:
    CHIPFanControlPercentSettingAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFanControlPercentSettingAttributeCallback();

    static void maybeDestroy(CHIPFanControlPercentSettingAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFanControlPercentSettingAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFanControlPercentSettingAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFanControlSpeedSettingAttributeCallback : public chip::Callback::Callback<CHIPFanControlClusterSpeedSettingAttributeCallbackType>
{
public:
    CHIPFanControlSpeedSettingAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFanControlSpeedSettingAttributeCallback();

    static void maybeDestroy(CHIPFanControlSpeedSettingAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFanControlSpeedSettingAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFanControlSpeedSettingAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFanControlGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPFanControlClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPFanControlGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFanControlGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPFanControlGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFanControlGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFanControlGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFanControlAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPFanControlClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPFanControlAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFanControlAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPFanControlAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFanControlAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFanControlAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFanControlEventListAttributeCallback : public chip::Callback::Callback<CHIPFanControlClusterEventListAttributeCallbackType>
{
public:
    CHIPFanControlEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFanControlEventListAttributeCallback();

    static void maybeDestroy(CHIPFanControlEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFanControlEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFanControlEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFanControlAttributeListAttributeCallback : public chip::Callback::Callback<CHIPFanControlClusterAttributeListAttributeCallbackType>
{
public:
    CHIPFanControlAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFanControlAttributeListAttributeCallback();

    static void maybeDestroy(CHIPFanControlAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFanControlAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFanControlAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPThermostatUserInterfaceConfigurationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPThermostatUserInterfaceConfigurationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPThermostatUserInterfaceConfigurationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatUserInterfaceConfigurationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPThermostatUserInterfaceConfigurationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatUserInterfaceConfigurationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatUserInterfaceConfigurationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatUserInterfaceConfigurationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPThermostatUserInterfaceConfigurationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPThermostatUserInterfaceConfigurationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatUserInterfaceConfigurationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPThermostatUserInterfaceConfigurationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatUserInterfaceConfigurationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatUserInterfaceConfigurationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatUserInterfaceConfigurationEventListAttributeCallback : public chip::Callback::Callback<CHIPThermostatUserInterfaceConfigurationClusterEventListAttributeCallbackType>
{
public:
    CHIPThermostatUserInterfaceConfigurationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatUserInterfaceConfigurationEventListAttributeCallback();

    static void maybeDestroy(CHIPThermostatUserInterfaceConfigurationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatUserInterfaceConfigurationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatUserInterfaceConfigurationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPThermostatUserInterfaceConfigurationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPThermostatUserInterfaceConfigurationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPThermostatUserInterfaceConfigurationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPThermostatUserInterfaceConfigurationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPThermostatUserInterfaceConfigurationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPThermostatUserInterfaceConfigurationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPThermostatUserInterfaceConfigurationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPColorControlNumberOfPrimariesAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterNumberOfPrimariesAttributeCallbackType>
{
public:
    CHIPColorControlNumberOfPrimariesAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlNumberOfPrimariesAttributeCallback();

    static void maybeDestroy(CHIPColorControlNumberOfPrimariesAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlNumberOfPrimariesAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlNumberOfPrimariesAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlPrimary1IntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterPrimary1IntensityAttributeCallbackType>
{
public:
    CHIPColorControlPrimary1IntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlPrimary1IntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlPrimary1IntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlPrimary1IntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlPrimary1IntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlPrimary2IntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterPrimary2IntensityAttributeCallbackType>
{
public:
    CHIPColorControlPrimary2IntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlPrimary2IntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlPrimary2IntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlPrimary2IntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlPrimary2IntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlPrimary3IntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterPrimary3IntensityAttributeCallbackType>
{
public:
    CHIPColorControlPrimary3IntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlPrimary3IntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlPrimary3IntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlPrimary3IntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlPrimary3IntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlPrimary4IntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterPrimary4IntensityAttributeCallbackType>
{
public:
    CHIPColorControlPrimary4IntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlPrimary4IntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlPrimary4IntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlPrimary4IntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlPrimary4IntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlPrimary5IntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterPrimary5IntensityAttributeCallbackType>
{
public:
    CHIPColorControlPrimary5IntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlPrimary5IntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlPrimary5IntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlPrimary5IntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlPrimary5IntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlPrimary6IntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterPrimary6IntensityAttributeCallbackType>
{
public:
    CHIPColorControlPrimary6IntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlPrimary6IntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlPrimary6IntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlPrimary6IntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlPrimary6IntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlColorPointRIntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterColorPointRIntensityAttributeCallbackType>
{
public:
    CHIPColorControlColorPointRIntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlColorPointRIntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlColorPointRIntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlColorPointRIntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlColorPointRIntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlColorPointGIntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterColorPointGIntensityAttributeCallbackType>
{
public:
    CHIPColorControlColorPointGIntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlColorPointGIntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlColorPointGIntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlColorPointGIntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlColorPointGIntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlColorPointBIntensityAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterColorPointBIntensityAttributeCallbackType>
{
public:
    CHIPColorControlColorPointBIntensityAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlColorPointBIntensityAttributeCallback();

    static void maybeDestroy(CHIPColorControlColorPointBIntensityAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlColorPointBIntensityAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlColorPointBIntensityAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlStartUpColorTemperatureMiredsAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterStartUpColorTemperatureMiredsAttributeCallbackType>
{
public:
    CHIPColorControlStartUpColorTemperatureMiredsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlStartUpColorTemperatureMiredsAttributeCallback();

    static void maybeDestroy(CHIPColorControlStartUpColorTemperatureMiredsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlStartUpColorTemperatureMiredsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlStartUpColorTemperatureMiredsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPColorControlGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPColorControlGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPColorControlAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPColorControlAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlEventListAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterEventListAttributeCallbackType>
{
public:
    CHIPColorControlEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlEventListAttributeCallback();

    static void maybeDestroy(CHIPColorControlEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPColorControlAttributeListAttributeCallback : public chip::Callback::Callback<CHIPColorControlClusterAttributeListAttributeCallbackType>
{
public:
    CHIPColorControlAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPColorControlAttributeListAttributeCallback();

    static void maybeDestroy(CHIPColorControlAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPColorControlAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPColorControlAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPBallastConfigurationIntrinsicBallastFactorAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterIntrinsicBallastFactorAttributeCallbackType>
{
public:
    CHIPBallastConfigurationIntrinsicBallastFactorAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationIntrinsicBallastFactorAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationIntrinsicBallastFactorAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationIntrinsicBallastFactorAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationIntrinsicBallastFactorAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBallastConfigurationBallastFactorAdjustmentAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterBallastFactorAdjustmentAttributeCallbackType>
{
public:
    CHIPBallastConfigurationBallastFactorAdjustmentAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationBallastFactorAdjustmentAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationBallastFactorAdjustmentAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationBallastFactorAdjustmentAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationBallastFactorAdjustmentAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBallastConfigurationLampRatedHoursAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterLampRatedHoursAttributeCallbackType>
{
public:
    CHIPBallastConfigurationLampRatedHoursAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationLampRatedHoursAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationLampRatedHoursAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationLampRatedHoursAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationLampRatedHoursAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBallastConfigurationLampBurnHoursAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterLampBurnHoursAttributeCallbackType>
{
public:
    CHIPBallastConfigurationLampBurnHoursAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationLampBurnHoursAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationLampBurnHoursAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationLampBurnHoursAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationLampBurnHoursAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBallastConfigurationLampBurnHoursTripPointAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterLampBurnHoursTripPointAttributeCallbackType>
{
public:
    CHIPBallastConfigurationLampBurnHoursTripPointAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationLampBurnHoursTripPointAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationLampBurnHoursTripPointAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationLampBurnHoursTripPointAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationLampBurnHoursTripPointAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBallastConfigurationGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPBallastConfigurationGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBallastConfigurationAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPBallastConfigurationAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBallastConfigurationEventListAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterEventListAttributeCallbackType>
{
public:
    CHIPBallastConfigurationEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationEventListAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPBallastConfigurationAttributeListAttributeCallback : public chip::Callback::Callback<CHIPBallastConfigurationClusterAttributeListAttributeCallbackType>
{
public:
    CHIPBallastConfigurationAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPBallastConfigurationAttributeListAttributeCallback();

    static void maybeDestroy(CHIPBallastConfigurationAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPBallastConfigurationAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPBallastConfigurationAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPIlluminanceMeasurementMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPIlluminanceMeasurementClusterMeasuredValueAttributeCallbackType>
{
public:
    CHIPIlluminanceMeasurementMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIlluminanceMeasurementMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPIlluminanceMeasurementMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIlluminanceMeasurementMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIlluminanceMeasurementMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIlluminanceMeasurementMinMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPIlluminanceMeasurementClusterMinMeasuredValueAttributeCallbackType>
{
public:
    CHIPIlluminanceMeasurementMinMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIlluminanceMeasurementMinMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPIlluminanceMeasurementMinMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIlluminanceMeasurementMinMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIlluminanceMeasurementMinMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIlluminanceMeasurementMaxMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPIlluminanceMeasurementClusterMaxMeasuredValueAttributeCallbackType>
{
public:
    CHIPIlluminanceMeasurementMaxMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIlluminanceMeasurementMaxMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPIlluminanceMeasurementMaxMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIlluminanceMeasurementMaxMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIlluminanceMeasurementMaxMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIlluminanceMeasurementLightSensorTypeAttributeCallback : public chip::Callback::Callback<CHIPIlluminanceMeasurementClusterLightSensorTypeAttributeCallbackType>
{
public:
    CHIPIlluminanceMeasurementLightSensorTypeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIlluminanceMeasurementLightSensorTypeAttributeCallback();

    static void maybeDestroy(CHIPIlluminanceMeasurementLightSensorTypeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIlluminanceMeasurementLightSensorTypeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIlluminanceMeasurementLightSensorTypeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIlluminanceMeasurementGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPIlluminanceMeasurementClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPIlluminanceMeasurementGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIlluminanceMeasurementGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPIlluminanceMeasurementGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIlluminanceMeasurementGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIlluminanceMeasurementGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIlluminanceMeasurementAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPIlluminanceMeasurementClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPIlluminanceMeasurementAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIlluminanceMeasurementAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPIlluminanceMeasurementAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIlluminanceMeasurementAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIlluminanceMeasurementAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIlluminanceMeasurementEventListAttributeCallback : public chip::Callback::Callback<CHIPIlluminanceMeasurementClusterEventListAttributeCallbackType>
{
public:
    CHIPIlluminanceMeasurementEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIlluminanceMeasurementEventListAttributeCallback();

    static void maybeDestroy(CHIPIlluminanceMeasurementEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIlluminanceMeasurementEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIlluminanceMeasurementEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPIlluminanceMeasurementAttributeListAttributeCallback : public chip::Callback::Callback<CHIPIlluminanceMeasurementClusterAttributeListAttributeCallbackType>
{
public:
    CHIPIlluminanceMeasurementAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPIlluminanceMeasurementAttributeListAttributeCallback();

    static void maybeDestroy(CHIPIlluminanceMeasurementAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPIlluminanceMeasurementAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPIlluminanceMeasurementAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPTemperatureMeasurementMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPTemperatureMeasurementClusterMeasuredValueAttributeCallbackType>
{
public:
    CHIPTemperatureMeasurementMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTemperatureMeasurementMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPTemperatureMeasurementMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTemperatureMeasurementMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTemperatureMeasurementMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTemperatureMeasurementMinMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPTemperatureMeasurementClusterMinMeasuredValueAttributeCallbackType>
{
public:
    CHIPTemperatureMeasurementMinMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTemperatureMeasurementMinMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPTemperatureMeasurementMinMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTemperatureMeasurementMinMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTemperatureMeasurementMinMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTemperatureMeasurementMaxMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPTemperatureMeasurementClusterMaxMeasuredValueAttributeCallbackType>
{
public:
    CHIPTemperatureMeasurementMaxMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTemperatureMeasurementMaxMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPTemperatureMeasurementMaxMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTemperatureMeasurementMaxMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTemperatureMeasurementMaxMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTemperatureMeasurementGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPTemperatureMeasurementClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPTemperatureMeasurementGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTemperatureMeasurementGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPTemperatureMeasurementGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTemperatureMeasurementGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTemperatureMeasurementGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTemperatureMeasurementAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPTemperatureMeasurementClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPTemperatureMeasurementAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTemperatureMeasurementAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPTemperatureMeasurementAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTemperatureMeasurementAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTemperatureMeasurementAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTemperatureMeasurementEventListAttributeCallback : public chip::Callback::Callback<CHIPTemperatureMeasurementClusterEventListAttributeCallbackType>
{
public:
    CHIPTemperatureMeasurementEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTemperatureMeasurementEventListAttributeCallback();

    static void maybeDestroy(CHIPTemperatureMeasurementEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTemperatureMeasurementEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTemperatureMeasurementEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTemperatureMeasurementAttributeListAttributeCallback : public chip::Callback::Callback<CHIPTemperatureMeasurementClusterAttributeListAttributeCallbackType>
{
public:
    CHIPTemperatureMeasurementAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTemperatureMeasurementAttributeListAttributeCallback();

    static void maybeDestroy(CHIPTemperatureMeasurementAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTemperatureMeasurementAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTemperatureMeasurementAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPPressureMeasurementMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterMeasuredValueAttributeCallbackType>
{
public:
    CHIPPressureMeasurementMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementMinMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterMinMeasuredValueAttributeCallbackType>
{
public:
    CHIPPressureMeasurementMinMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementMinMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementMinMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementMinMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementMinMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementMaxMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterMaxMeasuredValueAttributeCallbackType>
{
public:
    CHIPPressureMeasurementMaxMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementMaxMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementMaxMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementMaxMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementMaxMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementScaledValueAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterScaledValueAttributeCallbackType>
{
public:
    CHIPPressureMeasurementScaledValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementScaledValueAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementScaledValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementScaledValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementScaledValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementMinScaledValueAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterMinScaledValueAttributeCallbackType>
{
public:
    CHIPPressureMeasurementMinScaledValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementMinScaledValueAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementMinScaledValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementMinScaledValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementMinScaledValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementMaxScaledValueAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterMaxScaledValueAttributeCallbackType>
{
public:
    CHIPPressureMeasurementMaxScaledValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementMaxScaledValueAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementMaxScaledValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementMaxScaledValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementMaxScaledValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPPressureMeasurementGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPPressureMeasurementAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementEventListAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterEventListAttributeCallbackType>
{
public:
    CHIPPressureMeasurementEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementEventListAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPPressureMeasurementAttributeListAttributeCallback : public chip::Callback::Callback<CHIPPressureMeasurementClusterAttributeListAttributeCallbackType>
{
public:
    CHIPPressureMeasurementAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPPressureMeasurementAttributeListAttributeCallback();

    static void maybeDestroy(CHIPPressureMeasurementAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPPressureMeasurementAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPPressureMeasurementAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPFlowMeasurementMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPFlowMeasurementClusterMeasuredValueAttributeCallbackType>
{
public:
    CHIPFlowMeasurementMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFlowMeasurementMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPFlowMeasurementMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFlowMeasurementMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFlowMeasurementMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFlowMeasurementMinMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPFlowMeasurementClusterMinMeasuredValueAttributeCallbackType>
{
public:
    CHIPFlowMeasurementMinMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFlowMeasurementMinMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPFlowMeasurementMinMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFlowMeasurementMinMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFlowMeasurementMinMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFlowMeasurementMaxMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPFlowMeasurementClusterMaxMeasuredValueAttributeCallbackType>
{
public:
    CHIPFlowMeasurementMaxMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFlowMeasurementMaxMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPFlowMeasurementMaxMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFlowMeasurementMaxMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFlowMeasurementMaxMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFlowMeasurementGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPFlowMeasurementClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPFlowMeasurementGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFlowMeasurementGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPFlowMeasurementGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFlowMeasurementGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFlowMeasurementGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFlowMeasurementAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPFlowMeasurementClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPFlowMeasurementAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFlowMeasurementAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPFlowMeasurementAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFlowMeasurementAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFlowMeasurementAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFlowMeasurementEventListAttributeCallback : public chip::Callback::Callback<CHIPFlowMeasurementClusterEventListAttributeCallbackType>
{
public:
    CHIPFlowMeasurementEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFlowMeasurementEventListAttributeCallback();

    static void maybeDestroy(CHIPFlowMeasurementEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFlowMeasurementEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFlowMeasurementEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPFlowMeasurementAttributeListAttributeCallback : public chip::Callback::Callback<CHIPFlowMeasurementClusterAttributeListAttributeCallbackType>
{
public:
    CHIPFlowMeasurementAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPFlowMeasurementAttributeListAttributeCallback();

    static void maybeDestroy(CHIPFlowMeasurementAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPFlowMeasurementAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPFlowMeasurementAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPRelativeHumidityMeasurementMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPRelativeHumidityMeasurementClusterMeasuredValueAttributeCallbackType>
{
public:
    CHIPRelativeHumidityMeasurementMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPRelativeHumidityMeasurementMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPRelativeHumidityMeasurementMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPRelativeHumidityMeasurementMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPRelativeHumidityMeasurementMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPRelativeHumidityMeasurementMinMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPRelativeHumidityMeasurementClusterMinMeasuredValueAttributeCallbackType>
{
public:
    CHIPRelativeHumidityMeasurementMinMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPRelativeHumidityMeasurementMinMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPRelativeHumidityMeasurementMinMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPRelativeHumidityMeasurementMinMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPRelativeHumidityMeasurementMinMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPRelativeHumidityMeasurementMaxMeasuredValueAttributeCallback : public chip::Callback::Callback<CHIPRelativeHumidityMeasurementClusterMaxMeasuredValueAttributeCallbackType>
{
public:
    CHIPRelativeHumidityMeasurementMaxMeasuredValueAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPRelativeHumidityMeasurementMaxMeasuredValueAttributeCallback();

    static void maybeDestroy(CHIPRelativeHumidityMeasurementMaxMeasuredValueAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPRelativeHumidityMeasurementMaxMeasuredValueAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPRelativeHumidityMeasurementMaxMeasuredValueAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPRelativeHumidityMeasurementGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPRelativeHumidityMeasurementClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPRelativeHumidityMeasurementGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPRelativeHumidityMeasurementGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPRelativeHumidityMeasurementGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPRelativeHumidityMeasurementGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPRelativeHumidityMeasurementGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPRelativeHumidityMeasurementAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPRelativeHumidityMeasurementClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPRelativeHumidityMeasurementAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPRelativeHumidityMeasurementAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPRelativeHumidityMeasurementAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPRelativeHumidityMeasurementAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPRelativeHumidityMeasurementAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPRelativeHumidityMeasurementEventListAttributeCallback : public chip::Callback::Callback<CHIPRelativeHumidityMeasurementClusterEventListAttributeCallbackType>
{
public:
    CHIPRelativeHumidityMeasurementEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPRelativeHumidityMeasurementEventListAttributeCallback();

    static void maybeDestroy(CHIPRelativeHumidityMeasurementEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPRelativeHumidityMeasurementEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPRelativeHumidityMeasurementEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPRelativeHumidityMeasurementAttributeListAttributeCallback : public chip::Callback::Callback<CHIPRelativeHumidityMeasurementClusterAttributeListAttributeCallbackType>
{
public:
    CHIPRelativeHumidityMeasurementAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPRelativeHumidityMeasurementAttributeListAttributeCallback();

    static void maybeDestroy(CHIPRelativeHumidityMeasurementAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPRelativeHumidityMeasurementAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPRelativeHumidityMeasurementAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPOccupancySensingOccupancyAttributeCallback : public chip::Callback::Callback<CHIPOccupancySensingClusterOccupancyAttributeCallbackType>
{
public:
    CHIPOccupancySensingOccupancyAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOccupancySensingOccupancyAttributeCallback();

    static void maybeDestroy(CHIPOccupancySensingOccupancyAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOccupancySensingOccupancyAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::OccupancySensing::OccupancyBitmap> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOccupancySensingOccupancyAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOccupancySensingOccupancySensorTypeAttributeCallback : public chip::Callback::Callback<CHIPOccupancySensingClusterOccupancySensorTypeAttributeCallbackType>
{
public:
    CHIPOccupancySensingOccupancySensorTypeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOccupancySensingOccupancySensorTypeAttributeCallback();

    static void maybeDestroy(CHIPOccupancySensingOccupancySensorTypeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOccupancySensingOccupancySensorTypeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::OccupancySensing::OccupancySensorTypeEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOccupancySensingOccupancySensorTypeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOccupancySensingOccupancySensorTypeBitmapAttributeCallback : public chip::Callback::Callback<CHIPOccupancySensingClusterOccupancySensorTypeBitmapAttributeCallbackType>
{
public:
    CHIPOccupancySensingOccupancySensorTypeBitmapAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOccupancySensingOccupancySensorTypeBitmapAttributeCallback();

    static void maybeDestroy(CHIPOccupancySensingOccupancySensorTypeBitmapAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOccupancySensingOccupancySensorTypeBitmapAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::OccupancySensing::OccupancySensorTypeBitmap> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOccupancySensingOccupancySensorTypeBitmapAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOccupancySensingGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOccupancySensingClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPOccupancySensingGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOccupancySensingGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOccupancySensingGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOccupancySensingGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOccupancySensingGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOccupancySensingAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPOccupancySensingClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPOccupancySensingAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOccupancySensingAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPOccupancySensingAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOccupancySensingAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOccupancySensingAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOccupancySensingEventListAttributeCallback : public chip::Callback::Callback<CHIPOccupancySensingClusterEventListAttributeCallbackType>
{
public:
    CHIPOccupancySensingEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOccupancySensingEventListAttributeCallback();

    static void maybeDestroy(CHIPOccupancySensingEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOccupancySensingEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOccupancySensingEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPOccupancySensingAttributeListAttributeCallback : public chip::Callback::Callback<CHIPOccupancySensingClusterAttributeListAttributeCallbackType>
{
public:
    CHIPOccupancySensingAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPOccupancySensingAttributeListAttributeCallback();

    static void maybeDestroy(CHIPOccupancySensingAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPOccupancySensingAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPOccupancySensingAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPWakeOnLanGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPWakeOnLanClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPWakeOnLanGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWakeOnLanGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPWakeOnLanGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWakeOnLanGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWakeOnLanGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWakeOnLanAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPWakeOnLanClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPWakeOnLanAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWakeOnLanAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPWakeOnLanAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWakeOnLanAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWakeOnLanAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWakeOnLanEventListAttributeCallback : public chip::Callback::Callback<CHIPWakeOnLanClusterEventListAttributeCallbackType>
{
public:
    CHIPWakeOnLanEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWakeOnLanEventListAttributeCallback();

    static void maybeDestroy(CHIPWakeOnLanEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWakeOnLanEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWakeOnLanEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPWakeOnLanAttributeListAttributeCallback : public chip::Callback::Callback<CHIPWakeOnLanClusterAttributeListAttributeCallbackType>
{
public:
    CHIPWakeOnLanAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPWakeOnLanAttributeListAttributeCallback();

    static void maybeDestroy(CHIPWakeOnLanAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPWakeOnLanAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPWakeOnLanAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPChannelChannelListAttributeCallback : public chip::Callback::Callback<CHIPChannelClusterChannelListAttributeCallbackType>
{
public:
    CHIPChannelChannelListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPChannelChannelListAttributeCallback();

    static void maybeDestroy(CHIPChannelChannelListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPChannelChannelListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::Channel::Structs::ChannelInfoStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPChannelChannelListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPChannelLineupAttributeCallback : public chip::Callback::Callback<CHIPChannelClusterLineupAttributeCallbackType>
{
public:
    CHIPChannelLineupAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPChannelLineupAttributeCallback();

    static void maybeDestroy(CHIPChannelLineupAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPChannelLineupAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::Channel::Structs::LineupInfoStruct::DecodableType> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPChannelLineupAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPChannelCurrentChannelAttributeCallback : public chip::Callback::Callback<CHIPChannelClusterCurrentChannelAttributeCallbackType>
{
public:
    CHIPChannelCurrentChannelAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPChannelCurrentChannelAttributeCallback();

    static void maybeDestroy(CHIPChannelCurrentChannelAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPChannelCurrentChannelAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::Channel::Structs::ChannelInfoStruct::DecodableType> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPChannelCurrentChannelAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPChannelGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPChannelClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPChannelGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPChannelGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPChannelGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPChannelGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPChannelGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPChannelAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPChannelClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPChannelAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPChannelAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPChannelAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPChannelAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPChannelAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPChannelEventListAttributeCallback : public chip::Callback::Callback<CHIPChannelClusterEventListAttributeCallbackType>
{
public:
    CHIPChannelEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPChannelEventListAttributeCallback();

    static void maybeDestroy(CHIPChannelEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPChannelEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPChannelEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPChannelAttributeListAttributeCallback : public chip::Callback::Callback<CHIPChannelClusterAttributeListAttributeCallbackType>
{
public:
    CHIPChannelAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPChannelAttributeListAttributeCallback();

    static void maybeDestroy(CHIPChannelAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPChannelAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPChannelAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPTargetNavigatorTargetListAttributeCallback : public chip::Callback::Callback<CHIPTargetNavigatorClusterTargetListAttributeCallbackType>
{
public:
    CHIPTargetNavigatorTargetListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTargetNavigatorTargetListAttributeCallback();

    static void maybeDestroy(CHIPTargetNavigatorTargetListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTargetNavigatorTargetListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::TargetNavigator::Structs::TargetInfoStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTargetNavigatorTargetListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTargetNavigatorGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPTargetNavigatorClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPTargetNavigatorGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTargetNavigatorGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPTargetNavigatorGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTargetNavigatorGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTargetNavigatorGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTargetNavigatorAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPTargetNavigatorClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPTargetNavigatorAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTargetNavigatorAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPTargetNavigatorAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTargetNavigatorAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTargetNavigatorAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTargetNavigatorEventListAttributeCallback : public chip::Callback::Callback<CHIPTargetNavigatorClusterEventListAttributeCallbackType>
{
public:
    CHIPTargetNavigatorEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTargetNavigatorEventListAttributeCallback();

    static void maybeDestroy(CHIPTargetNavigatorEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTargetNavigatorEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTargetNavigatorEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPTargetNavigatorAttributeListAttributeCallback : public chip::Callback::Callback<CHIPTargetNavigatorClusterAttributeListAttributeCallbackType>
{
public:
    CHIPTargetNavigatorAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPTargetNavigatorAttributeListAttributeCallback();

    static void maybeDestroy(CHIPTargetNavigatorAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPTargetNavigatorAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPTargetNavigatorAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPMediaPlaybackCurrentStateAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterCurrentStateAttributeCallbackType>
{
public:
    CHIPMediaPlaybackCurrentStateAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackCurrentStateAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackCurrentStateAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackCurrentStateAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::MediaPlayback::PlaybackStateEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackCurrentStateAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackStartTimeAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterStartTimeAttributeCallbackType>
{
public:
    CHIPMediaPlaybackStartTimeAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackStartTimeAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackStartTimeAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackStartTimeAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackStartTimeAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackDurationAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterDurationAttributeCallbackType>
{
public:
    CHIPMediaPlaybackDurationAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackDurationAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackDurationAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackDurationAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackDurationAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackSampledPositionAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterSampledPositionAttributeCallbackType>
{
public:
    CHIPMediaPlaybackSampledPositionAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackSampledPositionAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackSampledPositionAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackSampledPositionAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::MediaPlayback::Structs::PlaybackPositionStruct::DecodableType> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackSampledPositionAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackSeekRangeEndAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterSeekRangeEndAttributeCallbackType>
{
public:
    CHIPMediaPlaybackSeekRangeEndAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackSeekRangeEndAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackSeekRangeEndAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackSeekRangeEndAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackSeekRangeEndAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackSeekRangeStartAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterSeekRangeStartAttributeCallbackType>
{
public:
    CHIPMediaPlaybackSeekRangeStartAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackSeekRangeStartAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackSeekRangeStartAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackSeekRangeStartAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackSeekRangeStartAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPMediaPlaybackGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPMediaPlaybackAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackEventListAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterEventListAttributeCallbackType>
{
public:
    CHIPMediaPlaybackEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackEventListAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaPlaybackAttributeListAttributeCallback : public chip::Callback::Callback<CHIPMediaPlaybackClusterAttributeListAttributeCallbackType>
{
public:
    CHIPMediaPlaybackAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaPlaybackAttributeListAttributeCallback();

    static void maybeDestroy(CHIPMediaPlaybackAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaPlaybackAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaPlaybackAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPMediaInputInputListAttributeCallback : public chip::Callback::Callback<CHIPMediaInputClusterInputListAttributeCallbackType>
{
public:
    CHIPMediaInputInputListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaInputInputListAttributeCallback();

    static void maybeDestroy(CHIPMediaInputInputListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaInputInputListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::MediaInput::Structs::InputInfoStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaInputInputListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaInputGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPMediaInputClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPMediaInputGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaInputGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPMediaInputGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaInputGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaInputGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaInputAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPMediaInputClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPMediaInputAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaInputAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPMediaInputAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaInputAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaInputAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaInputEventListAttributeCallback : public chip::Callback::Callback<CHIPMediaInputClusterEventListAttributeCallbackType>
{
public:
    CHIPMediaInputEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaInputEventListAttributeCallback();

    static void maybeDestroy(CHIPMediaInputEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaInputEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaInputEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPMediaInputAttributeListAttributeCallback : public chip::Callback::Callback<CHIPMediaInputClusterAttributeListAttributeCallbackType>
{
public:
    CHIPMediaInputAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPMediaInputAttributeListAttributeCallback();

    static void maybeDestroy(CHIPMediaInputAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPMediaInputAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPMediaInputAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPLowPowerGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPLowPowerClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPLowPowerGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLowPowerGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPLowPowerGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLowPowerGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLowPowerGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLowPowerAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPLowPowerClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPLowPowerAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLowPowerAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPLowPowerAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLowPowerAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLowPowerAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLowPowerEventListAttributeCallback : public chip::Callback::Callback<CHIPLowPowerClusterEventListAttributeCallbackType>
{
public:
    CHIPLowPowerEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLowPowerEventListAttributeCallback();

    static void maybeDestroy(CHIPLowPowerEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLowPowerEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLowPowerEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPLowPowerAttributeListAttributeCallback : public chip::Callback::Callback<CHIPLowPowerClusterAttributeListAttributeCallbackType>
{
public:
    CHIPLowPowerAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPLowPowerAttributeListAttributeCallback();

    static void maybeDestroy(CHIPLowPowerAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPLowPowerAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPLowPowerAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPKeypadInputGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPKeypadInputClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPKeypadInputGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPKeypadInputGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPKeypadInputGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPKeypadInputGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPKeypadInputGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPKeypadInputAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPKeypadInputClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPKeypadInputAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPKeypadInputAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPKeypadInputAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPKeypadInputAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPKeypadInputAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPKeypadInputEventListAttributeCallback : public chip::Callback::Callback<CHIPKeypadInputClusterEventListAttributeCallbackType>
{
public:
    CHIPKeypadInputEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPKeypadInputEventListAttributeCallback();

    static void maybeDestroy(CHIPKeypadInputEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPKeypadInputEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPKeypadInputEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPKeypadInputAttributeListAttributeCallback : public chip::Callback::Callback<CHIPKeypadInputClusterAttributeListAttributeCallbackType>
{
public:
    CHIPKeypadInputAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPKeypadInputAttributeListAttributeCallback();

    static void maybeDestroy(CHIPKeypadInputAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPKeypadInputAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPKeypadInputAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPContentLauncherAcceptHeaderAttributeCallback : public chip::Callback::Callback<CHIPContentLauncherClusterAcceptHeaderAttributeCallbackType>
{
public:
    CHIPContentLauncherAcceptHeaderAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPContentLauncherAcceptHeaderAttributeCallback();

    static void maybeDestroy(CHIPContentLauncherAcceptHeaderAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPContentLauncherAcceptHeaderAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CharSpan> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPContentLauncherAcceptHeaderAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPContentLauncherGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPContentLauncherClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPContentLauncherGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPContentLauncherGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPContentLauncherGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPContentLauncherGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPContentLauncherGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPContentLauncherAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPContentLauncherClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPContentLauncherAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPContentLauncherAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPContentLauncherAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPContentLauncherAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPContentLauncherAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPContentLauncherEventListAttributeCallback : public chip::Callback::Callback<CHIPContentLauncherClusterEventListAttributeCallbackType>
{
public:
    CHIPContentLauncherEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPContentLauncherEventListAttributeCallback();

    static void maybeDestroy(CHIPContentLauncherEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPContentLauncherEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPContentLauncherEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPContentLauncherAttributeListAttributeCallback : public chip::Callback::Callback<CHIPContentLauncherClusterAttributeListAttributeCallbackType>
{
public:
    CHIPContentLauncherAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPContentLauncherAttributeListAttributeCallback();

    static void maybeDestroy(CHIPContentLauncherAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPContentLauncherAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPContentLauncherAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPAudioOutputOutputListAttributeCallback : public chip::Callback::Callback<CHIPAudioOutputClusterOutputListAttributeCallbackType>
{
public:
    CHIPAudioOutputOutputListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAudioOutputOutputListAttributeCallback();

    static void maybeDestroy(CHIPAudioOutputOutputListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAudioOutputOutputListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::AudioOutput::Structs::OutputInfoStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAudioOutputOutputListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAudioOutputGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPAudioOutputClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPAudioOutputGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAudioOutputGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPAudioOutputGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAudioOutputGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAudioOutputGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAudioOutputAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPAudioOutputClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPAudioOutputAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAudioOutputAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPAudioOutputAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAudioOutputAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAudioOutputAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAudioOutputEventListAttributeCallback : public chip::Callback::Callback<CHIPAudioOutputClusterEventListAttributeCallbackType>
{
public:
    CHIPAudioOutputEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAudioOutputEventListAttributeCallback();

    static void maybeDestroy(CHIPAudioOutputEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAudioOutputEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAudioOutputEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAudioOutputAttributeListAttributeCallback : public chip::Callback::Callback<CHIPAudioOutputClusterAttributeListAttributeCallbackType>
{
public:
    CHIPAudioOutputAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAudioOutputAttributeListAttributeCallback();

    static void maybeDestroy(CHIPAudioOutputAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAudioOutputAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAudioOutputAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPApplicationLauncherCatalogListAttributeCallback : public chip::Callback::Callback<CHIPApplicationLauncherClusterCatalogListAttributeCallbackType>
{
public:
    CHIPApplicationLauncherCatalogListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationLauncherCatalogListAttributeCallback();

    static void maybeDestroy(CHIPApplicationLauncherCatalogListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationLauncherCatalogListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<uint16_t> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationLauncherCatalogListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationLauncherCurrentAppAttributeCallback : public chip::Callback::Callback<CHIPApplicationLauncherClusterCurrentAppAttributeCallbackType>
{
public:
    CHIPApplicationLauncherCurrentAppAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationLauncherCurrentAppAttributeCallback();

    static void maybeDestroy(CHIPApplicationLauncherCurrentAppAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationLauncherCurrentAppAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::ApplicationLauncher::Structs::ApplicationEPStruct::DecodableType> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationLauncherCurrentAppAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationLauncherGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPApplicationLauncherClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPApplicationLauncherGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationLauncherGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPApplicationLauncherGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationLauncherGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationLauncherGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationLauncherAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPApplicationLauncherClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPApplicationLauncherAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationLauncherAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPApplicationLauncherAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationLauncherAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationLauncherAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationLauncherEventListAttributeCallback : public chip::Callback::Callback<CHIPApplicationLauncherClusterEventListAttributeCallbackType>
{
public:
    CHIPApplicationLauncherEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationLauncherEventListAttributeCallback();

    static void maybeDestroy(CHIPApplicationLauncherEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationLauncherEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationLauncherEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationLauncherAttributeListAttributeCallback : public chip::Callback::Callback<CHIPApplicationLauncherClusterAttributeListAttributeCallbackType>
{
public:
    CHIPApplicationLauncherAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationLauncherAttributeListAttributeCallback();

    static void maybeDestroy(CHIPApplicationLauncherAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationLauncherAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationLauncherAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPApplicationBasicVendorIDAttributeCallback : public chip::Callback::Callback<CHIPApplicationBasicClusterVendorIDAttributeCallbackType>
{
public:
    CHIPApplicationBasicVendorIDAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationBasicVendorIDAttributeCallback();

    static void maybeDestroy(CHIPApplicationBasicVendorIDAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationBasicVendorIDAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::VendorId value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationBasicVendorIDAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationBasicApplicationAttributeCallback : public chip::Callback::Callback<CHIPApplicationBasicClusterApplicationAttributeCallbackType>
{
public:
    CHIPApplicationBasicApplicationAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationBasicApplicationAttributeCallback();

    static void maybeDestroy(CHIPApplicationBasicApplicationAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationBasicApplicationAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::ApplicationBasic::Structs::ApplicationStruct::DecodableType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationBasicApplicationAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationBasicStatusAttributeCallback : public chip::Callback::Callback<CHIPApplicationBasicClusterStatusAttributeCallbackType>
{
public:
    CHIPApplicationBasicStatusAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationBasicStatusAttributeCallback();

    static void maybeDestroy(CHIPApplicationBasicStatusAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationBasicStatusAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::ApplicationBasic::ApplicationStatusEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationBasicStatusAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationBasicAllowedVendorListAttributeCallback : public chip::Callback::Callback<CHIPApplicationBasicClusterAllowedVendorListAttributeCallbackType>
{
public:
    CHIPApplicationBasicAllowedVendorListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationBasicAllowedVendorListAttributeCallback();

    static void maybeDestroy(CHIPApplicationBasicAllowedVendorListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationBasicAllowedVendorListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::VendorId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationBasicAllowedVendorListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationBasicGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPApplicationBasicClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPApplicationBasicGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationBasicGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPApplicationBasicGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationBasicGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationBasicGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationBasicAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPApplicationBasicClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPApplicationBasicAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationBasicAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPApplicationBasicAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationBasicAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationBasicAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationBasicEventListAttributeCallback : public chip::Callback::Callback<CHIPApplicationBasicClusterEventListAttributeCallbackType>
{
public:
    CHIPApplicationBasicEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationBasicEventListAttributeCallback();

    static void maybeDestroy(CHIPApplicationBasicEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationBasicEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationBasicEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPApplicationBasicAttributeListAttributeCallback : public chip::Callback::Callback<CHIPApplicationBasicClusterAttributeListAttributeCallbackType>
{
public:
    CHIPApplicationBasicAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPApplicationBasicAttributeListAttributeCallback();

    static void maybeDestroy(CHIPApplicationBasicAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPApplicationBasicAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPApplicationBasicAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPAccountLoginGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPAccountLoginClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPAccountLoginGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccountLoginGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPAccountLoginGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccountLoginGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccountLoginGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAccountLoginAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPAccountLoginClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPAccountLoginAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccountLoginAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPAccountLoginAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccountLoginAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccountLoginAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAccountLoginEventListAttributeCallback : public chip::Callback::Callback<CHIPAccountLoginClusterEventListAttributeCallbackType>
{
public:
    CHIPAccountLoginEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccountLoginEventListAttributeCallback();

    static void maybeDestroy(CHIPAccountLoginEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccountLoginEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccountLoginEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPAccountLoginAttributeListAttributeCallback : public chip::Callback::Callback<CHIPAccountLoginClusterAttributeListAttributeCallbackType>
{
public:
    CHIPAccountLoginAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPAccountLoginAttributeListAttributeCallback();

    static void maybeDestroy(CHIPAccountLoginAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPAccountLoginAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPAccountLoginAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPElectricalMeasurementGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPElectricalMeasurementClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPElectricalMeasurementGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPElectricalMeasurementGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPElectricalMeasurementGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPElectricalMeasurementGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPElectricalMeasurementGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPElectricalMeasurementAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPElectricalMeasurementClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPElectricalMeasurementAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPElectricalMeasurementAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPElectricalMeasurementAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPElectricalMeasurementAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPElectricalMeasurementAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPElectricalMeasurementEventListAttributeCallback : public chip::Callback::Callback<CHIPElectricalMeasurementClusterEventListAttributeCallbackType>
{
public:
    CHIPElectricalMeasurementEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPElectricalMeasurementEventListAttributeCallback();

    static void maybeDestroy(CHIPElectricalMeasurementEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPElectricalMeasurementEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPElectricalMeasurementEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPElectricalMeasurementAttributeListAttributeCallback : public chip::Callback::Callback<CHIPElectricalMeasurementClusterAttributeListAttributeCallbackType>
{
public:
    CHIPElectricalMeasurementAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPElectricalMeasurementAttributeListAttributeCallback();

    static void maybeDestroy(CHIPElectricalMeasurementAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPElectricalMeasurementAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPElectricalMeasurementAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

  
class CHIPUnitTestingBitmap8AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterBitmap8AttributeCallbackType>
{
public:
    CHIPUnitTestingBitmap8AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingBitmap8AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingBitmap8AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingBitmap8AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::UnitTesting::Bitmap8MaskMap> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingBitmap8AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingBitmap16AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterBitmap16AttributeCallbackType>
{
public:
    CHIPUnitTestingBitmap16AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingBitmap16AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingBitmap16AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingBitmap16AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::UnitTesting::Bitmap16MaskMap> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingBitmap16AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingBitmap32AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterBitmap32AttributeCallbackType>
{
public:
    CHIPUnitTestingBitmap32AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingBitmap32AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingBitmap32AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingBitmap32AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::UnitTesting::Bitmap32MaskMap> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingBitmap32AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingBitmap64AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterBitmap64AttributeCallbackType>
{
public:
    CHIPUnitTestingBitmap64AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingBitmap64AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingBitmap64AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingBitmap64AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::BitMask<chip::app::Clusters::UnitTesting::Bitmap64MaskMap> value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingBitmap64AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingListInt8uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterListInt8uAttributeCallbackType>
{
public:
    CHIPUnitTestingListInt8uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingListInt8uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingListInt8uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingListInt8uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<uint8_t> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingListInt8uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingListOctetStringAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterListOctetStringAttributeCallbackType>
{
public:
    CHIPUnitTestingListOctetStringAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingListOctetStringAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingListOctetStringAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingListOctetStringAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::ByteSpan> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingListOctetStringAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingListStructOctetStringAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterListStructOctetStringAttributeCallbackType>
{
public:
    CHIPUnitTestingListStructOctetStringAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingListStructOctetStringAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingListStructOctetStringAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingListStructOctetStringAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::UnitTesting::Structs::TestListStructOctet::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingListStructOctetStringAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingEpochUsAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterEpochUsAttributeCallbackType>
{
public:
    CHIPUnitTestingEpochUsAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingEpochUsAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingEpochUsAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingEpochUsAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, uint64_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingEpochUsAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingEpochSAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterEpochSAttributeCallbackType>
{
public:
    CHIPUnitTestingEpochSAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingEpochSAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingEpochSAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingEpochSAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, uint32_t value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingEpochSAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingVendorIdAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterVendorIdAttributeCallbackType>
{
public:
    CHIPUnitTestingVendorIdAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingVendorIdAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingVendorIdAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingVendorIdAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::VendorId value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingVendorIdAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingListNullablesAndOptionalsStructAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterListNullablesAndOptionalsStructAttributeCallbackType>
{
public:
    CHIPUnitTestingListNullablesAndOptionalsStructAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingListNullablesAndOptionalsStructAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingListNullablesAndOptionalsStructAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingListNullablesAndOptionalsStructAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::UnitTesting::Structs::NullablesAndOptionalsStruct::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingListNullablesAndOptionalsStructAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingEnumAttrAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterEnumAttrAttributeCallbackType>
{
public:
    CHIPUnitTestingEnumAttrAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingEnumAttrAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingEnumAttrAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingEnumAttrAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::UnitTesting::SimpleEnum value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingEnumAttrAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingStructAttrAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterStructAttrAttributeCallbackType>
{
public:
    CHIPUnitTestingStructAttrAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingStructAttrAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingStructAttrAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingStructAttrAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, chip::app::Clusters::UnitTesting::Structs::SimpleStruct::DecodableType value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingStructAttrAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingListLongOctetStringAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterListLongOctetStringAttributeCallbackType>
{
public:
    CHIPUnitTestingListLongOctetStringAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingListLongOctetStringAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingListLongOctetStringAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingListLongOctetStringAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::ByteSpan> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingListLongOctetStringAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingListFabricScopedAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterListFabricScopedAttributeCallbackType>
{
public:
    CHIPUnitTestingListFabricScopedAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingListFabricScopedAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingListFabricScopedAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingListFabricScopedAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::app::Clusters::UnitTesting::Structs::TestFabricScoped::DecodableType> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingListFabricScopedAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableBooleanAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableBooleanAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableBooleanAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableBooleanAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableBooleanAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableBooleanAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<bool> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableBooleanAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableBitmap8AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableBitmap8AttributeCallbackType>
{
public:
    CHIPUnitTestingNullableBitmap8AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableBitmap8AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableBitmap8AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableBitmap8AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::BitMask<chip::app::Clusters::UnitTesting::Bitmap8MaskMap>> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableBitmap8AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableBitmap16AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableBitmap16AttributeCallbackType>
{
public:
    CHIPUnitTestingNullableBitmap16AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableBitmap16AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableBitmap16AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableBitmap16AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::BitMask<chip::app::Clusters::UnitTesting::Bitmap16MaskMap>> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableBitmap16AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableBitmap32AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableBitmap32AttributeCallbackType>
{
public:
    CHIPUnitTestingNullableBitmap32AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableBitmap32AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableBitmap32AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableBitmap32AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::BitMask<chip::app::Clusters::UnitTesting::Bitmap32MaskMap>> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableBitmap32AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableBitmap64AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableBitmap64AttributeCallbackType>
{
public:
    CHIPUnitTestingNullableBitmap64AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableBitmap64AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableBitmap64AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableBitmap64AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::BitMask<chip::app::Clusters::UnitTesting::Bitmap64MaskMap>> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableBitmap64AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt8uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt8uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt8uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt8uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt8uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt8uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt8uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt16uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt16uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt16uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt16uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt16uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt16uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt16uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt24uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt24uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt24uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt24uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt24uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt24uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt24uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt32uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt32uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt32uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt32uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt32uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt32uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt32uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt40uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt40uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt40uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt40uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt40uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt40uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt40uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt48uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt48uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt48uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt48uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt48uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt48uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt48uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt56uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt56uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt56uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt56uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt56uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt56uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt56uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt64uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt64uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt64uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt64uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt64uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt64uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt64uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt8sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt8sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt8sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt8sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt8sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt8sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt8sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt16sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt16sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt16sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt16sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt16sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt16sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt16sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt24sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt24sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt24sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt24sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt24sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt24sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt24sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt32sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt32sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt32sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt32sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt32sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt32sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int32_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt32sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt40sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt40sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt40sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt40sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt40sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt40sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt40sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt48sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt48sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt48sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt48sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt48sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt48sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt48sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt56sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt56sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt56sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt56sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt56sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt56sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt56sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableInt64sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableInt64sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableInt64sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableInt64sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableInt64sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableInt64sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int64_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableInt64sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableEnum8AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableEnum8AttributeCallbackType>
{
public:
    CHIPUnitTestingNullableEnum8AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableEnum8AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableEnum8AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableEnum8AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableEnum8AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableEnum16AttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableEnum16AttributeCallbackType>
{
public:
    CHIPUnitTestingNullableEnum16AttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableEnum16AttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableEnum16AttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableEnum16AttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableEnum16AttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableFloatSingleAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableFloatSingleAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableFloatSingleAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableFloatSingleAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableFloatSingleAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableFloatSingleAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<float> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableFloatSingleAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableFloatDoubleAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableFloatDoubleAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableFloatDoubleAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableFloatDoubleAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableFloatDoubleAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableFloatDoubleAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<double> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableFloatDoubleAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableOctetStringAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableOctetStringAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableOctetStringAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableOctetStringAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableOctetStringAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableOctetStringAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::ByteSpan> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableOctetStringAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableCharStringAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableCharStringAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableCharStringAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableCharStringAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableCharStringAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableCharStringAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::CharSpan> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableCharStringAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableEnumAttrAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableEnumAttrAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableEnumAttrAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableEnumAttrAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableEnumAttrAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableEnumAttrAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::UnitTesting::SimpleEnum> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableEnumAttrAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableStructAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableStructAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableStructAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableStructAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableStructAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableStructAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<chip::app::Clusters::UnitTesting::Structs::SimpleStruct::DecodableType> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableStructAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableRangeRestrictedInt8uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableRangeRestrictedInt8uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableRangeRestrictedInt8uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableRangeRestrictedInt8uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableRangeRestrictedInt8uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableRangeRestrictedInt8uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableRangeRestrictedInt8uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableRangeRestrictedInt8sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableRangeRestrictedInt8sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableRangeRestrictedInt8sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableRangeRestrictedInt8sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableRangeRestrictedInt8sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableRangeRestrictedInt8sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int8_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableRangeRestrictedInt8sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableRangeRestrictedInt16uAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableRangeRestrictedInt16uAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableRangeRestrictedInt16uAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableRangeRestrictedInt16uAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableRangeRestrictedInt16uAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableRangeRestrictedInt16uAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<uint16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableRangeRestrictedInt16uAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingNullableRangeRestrictedInt16sAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterNullableRangeRestrictedInt16sAttributeCallbackType>
{
public:
    CHIPUnitTestingNullableRangeRestrictedInt16sAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingNullableRangeRestrictedInt16sAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingNullableRangeRestrictedInt16sAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingNullableRangeRestrictedInt16sAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::Nullable<int16_t> & value);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingNullableRangeRestrictedInt16sAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingGeneratedCommandListAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterGeneratedCommandListAttributeCallbackType>
{
public:
    CHIPUnitTestingGeneratedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingGeneratedCommandListAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingGeneratedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingGeneratedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingGeneratedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingAcceptedCommandListAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterAcceptedCommandListAttributeCallbackType>
{
public:
    CHIPUnitTestingAcceptedCommandListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingAcceptedCommandListAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingAcceptedCommandListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingAcceptedCommandListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::CommandId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingAcceptedCommandListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingEventListAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterEventListAttributeCallbackType>
{
public:
    CHIPUnitTestingEventListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingEventListAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingEventListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingEventListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::EventId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingEventListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  
class CHIPUnitTestingAttributeListAttributeCallback : public chip::Callback::Callback<CHIPUnitTestingClusterAttributeListAttributeCallbackType>
{
public:
    CHIPUnitTestingAttributeListAttributeCallback(jobject javaCallback, bool keepAlive = false);

    ~CHIPUnitTestingAttributeListAttributeCallback();

    static void maybeDestroy(CHIPUnitTestingAttributeListAttributeCallback * callback) {
        if (!callback->keepAlive) {
            callback->Cancel();
            chip::Platform::Delete<CHIPUnitTestingAttributeListAttributeCallback>(callback);
        }
    }

    static void CallbackFn(void * context, const chip::app::DataModel::DecodableList<chip::AttributeId> & list);
    static void OnSubscriptionEstablished(void * context, chip::SubscriptionId subscriptionId) {
        CHIP_ERROR err = chip::JniReferences::GetInstance().CallSubscriptionEstablished(reinterpret_cast<CHIPUnitTestingAttributeListAttributeCallback *>(context)->javaCallbackRef, subscriptionId);
        VerifyOrReturn(err == CHIP_NO_ERROR, ChipLogError(Zcl, "Error calling onSubscriptionEstablished: %s", ErrorStr(err)));
    };

private:
    jobject javaCallbackRef;
    bool keepAlive;
};

  

