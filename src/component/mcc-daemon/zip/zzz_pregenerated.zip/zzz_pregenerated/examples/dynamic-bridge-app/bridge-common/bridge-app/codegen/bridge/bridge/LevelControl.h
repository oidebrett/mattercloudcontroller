#pragma once

#include "BridgeGlobalStructs.h"
#include "GeneratedClusters.h"

namespace clusters {
struct LevelControlCluster : public GeneratedCluster
{

  LevelControlCluster() :
      mCurrentLevel(chip::CharSpan("currentLevel"), 0, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mRemainingTime(chip::CharSpan("remainingTime"), 1, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2),
      mMinLevel(chip::CharSpan("minLevel"), 2, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mMaxLevel(chip::CharSpan("maxLevel"), 3, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mCurrentFrequency(chip::CharSpan("currentFrequency"), 4, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2),
      mMinFrequency(chip::CharSpan("minFrequency"), 5, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2),
      mMaxFrequency(chip::CharSpan("maxFrequency"), 6, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2),
      mOptions(chip::CharSpan("options"), 15, ATTRIBUTE_MASK_WRITABLE | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_BITMAP8_ATTRIBUTE_TYPE, 1),
      mOnOffTransitionTime(chip::CharSpan("onOffTransitionTime"), 16, ATTRIBUTE_MASK_WRITABLE | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2),
      mOnLevel(chip::CharSpan("onLevel"), 17, ATTRIBUTE_MASK_WRITABLE | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mOnTransitionTime(chip::CharSpan("onTransitionTime"), 18, ATTRIBUTE_MASK_WRITABLE | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2),
      mOffTransitionTime(chip::CharSpan("offTransitionTime"), 19, ATTRIBUTE_MASK_WRITABLE | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2),
      mDefaultMoveRate(chip::CharSpan("defaultMoveRate"), 20, ATTRIBUTE_MASK_WRITABLE | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mStartUpCurrentLevel(chip::CharSpan("startUpCurrentLevel"), 16384, ATTRIBUTE_MASK_WRITABLE | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mFeatureMap(chip::CharSpan("featureMap"), 65532, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_BITMAP32_ATTRIBUTE_TYPE, 4),
      mClusterRevision(chip::CharSpan("clusterRevision"), 65533, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2, ZCL_LEVEL_CONTROL_CLUSTER_REVISION)
  {
  }

  static constexpr uint32_t kClusterId =8;
  chip::ClusterId GetClusterId() override { return kClusterId; }

  std::vector<AttributeInterface*> GetAttributes() override
  {
    return std::vector<AttributeInterface*>({
      static_cast<AttributeInterface*>(&mCurrentLevel),
      static_cast<AttributeInterface*>(&mRemainingTime),
      static_cast<AttributeInterface*>(&mMinLevel),
      static_cast<AttributeInterface*>(&mMaxLevel),
      static_cast<AttributeInterface*>(&mCurrentFrequency),
      static_cast<AttributeInterface*>(&mMinFrequency),
      static_cast<AttributeInterface*>(&mMaxFrequency),
      static_cast<AttributeInterface*>(&mOptions),
      static_cast<AttributeInterface*>(&mOnOffTransitionTime),
      static_cast<AttributeInterface*>(&mOnLevel),
      static_cast<AttributeInterface*>(&mOnTransitionTime),
      static_cast<AttributeInterface*>(&mOffTransitionTime),
      static_cast<AttributeInterface*>(&mDefaultMoveRate),
      static_cast<AttributeInterface*>(&mStartUpCurrentLevel),
      static_cast<AttributeInterface*>(&mFeatureMap),
      static_cast<AttributeInterface*>(&mClusterRevision),
    });
  }


  Attribute<::chip::Optional<::chip::app::DataModel::Nullable<uint8_t>>> mCurrentLevel;
  Attribute<uint16_t> mRemainingTime;
  Attribute<uint8_t> mMinLevel;
  Attribute<uint8_t> mMaxLevel;
  Attribute<uint16_t> mCurrentFrequency;
  Attribute<uint16_t> mMinFrequency;
  Attribute<uint16_t> mMaxFrequency;
  Attribute<uint8_t> mOptions;
  Attribute<uint16_t> mOnOffTransitionTime;
  Attribute<::chip::Optional<::chip::app::DataModel::Nullable<uint8_t>>> mOnLevel;
  Attribute<::chip::Optional<::chip::app::DataModel::Nullable<uint16_t>>> mOnTransitionTime;
  Attribute<::chip::Optional<::chip::app::DataModel::Nullable<uint16_t>>> mOffTransitionTime;
  Attribute<::chip::Optional<::chip::app::DataModel::Nullable<uint8_t>>> mDefaultMoveRate;
  Attribute<::chip::Optional<::chip::app::DataModel::Nullable<uint8_t>>> mStartUpCurrentLevel;
  Attribute<uint32_t> mFeatureMap;
  Attribute<uint16_t> mClusterRevision;
  static const chip::CommandId mIncomingCommandList[];
  const chip::CommandId * GetIncomingCommandList() override
  {
    return mIncomingCommandList;
  }
};
#ifndef LEVEL_CONTROL_CLUSTER_INCOMING_COMMANDS
#define LEVEL_CONTROL_CLUSTER_INCOMING_COMMANDS
const chip::CommandId LevelControlCluster::mIncomingCommandList[] = {
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  chip::kInvalidCommandId
};
#endif

}
