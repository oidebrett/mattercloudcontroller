#pragma once

#include "BridgeGlobalStructs.h"
#include "GeneratedClusters.h"

namespace clusters {
struct SwitchCluster : public GeneratedCluster
{

  SwitchCluster() :
      mNumberOfPositions(chip::CharSpan("numberOfPositions"), 0, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mCurrentPosition(chip::CharSpan("currentPosition"), 1, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mMultiPressMax(chip::CharSpan("multiPressMax"), 2, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT8U_ATTRIBUTE_TYPE, 1),
      mFeatureMap(chip::CharSpan("featureMap"), 65532, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_BITMAP32_ATTRIBUTE_TYPE, 4),
      mClusterRevision(chip::CharSpan("clusterRevision"), 65533, 0 | ZAP_ATTRIBUTE_MASK(EXTERNAL_STORAGE), ZCL_INT16U_ATTRIBUTE_TYPE, 2, ZCL_SWITCH_CLUSTER_REVISION)
  {
  }

  static constexpr uint32_t kClusterId =59;
  chip::ClusterId GetClusterId() override { return kClusterId; }

  std::vector<AttributeInterface*> GetAttributes() override
  {
    return std::vector<AttributeInterface*>({
      static_cast<AttributeInterface*>(&mNumberOfPositions),
      static_cast<AttributeInterface*>(&mCurrentPosition),
      static_cast<AttributeInterface*>(&mMultiPressMax),
      static_cast<AttributeInterface*>(&mFeatureMap),
      static_cast<AttributeInterface*>(&mClusterRevision),
    });
  }


  Attribute<uint8_t> mNumberOfPositions;
  Attribute<uint8_t> mCurrentPosition;
  Attribute<uint8_t> mMultiPressMax;
  Attribute<uint32_t> mFeatureMap;
  Attribute<uint16_t> mClusterRevision;
};

}
